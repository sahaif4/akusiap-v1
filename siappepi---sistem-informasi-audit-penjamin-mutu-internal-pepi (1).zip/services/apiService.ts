import { User, Unit, CurrentUser, StandardDocument, AuditorProfile, UnitProfile, Instrument, DocumentStatus, FindingType, RiskLevel, Role, UnitSubmissionStatus, Standard } from '../types';
import { DashboardData, ActivityLogItem, UnitCode } from '../types/dashboard';

/**
 * =============================================================================
 * API SERVICE V2 (WITH MOCK DATA FALLBACK)
 * =============================================================================
 * This service now implements an "offline" or "demo" mode.
 * If a fetch call to the Django backend fails (e.g., CORS error, server down),
 * it will catch the error and seamlessly fall back to using a local mock
 * dataset. This makes the frontend fully interactive for demonstration
 * and development purposes, even without a running backend.
 * =============================================================================
 */

const API_BASE_URL = 'http://127.0.0.1:8000/api';
const API_DELAY = 400; // ms

// --- MOCK DATABASE ---
let MOCK_UNITS: Unit[] = [
  { id: 1, kode_unit: "TMP", nama_unit: "Prodi Teknologi Mekanisasi Pertanian", jenis_unit: "prodi" },
  { id: 2, kode_unit: "TAP", nama_unit: "Prodi Tata Air Pertanian", jenis_unit: "prodi" },
  { id: 3, kode_unit: "THP", nama_unit: "Prodi Teknologi Hasil Pertanian", jenis_unit: "prodi" },
  { id: 4, kode_unit: "DIR", nama_unit: "Direktorat", jenis_unit: "Manajemen" },
  { id: 5, kode_unit: "UPM", nama_unit: "Unit Penjaminan Mutu", jenis_unit: "pendukung" },
  { id: 6, kode_unit: "AAK", nama_unit: "Bagian Administrasi Akademik & Kemahasiswaan", jenis_unit: "pendukung" },
  { id: 7, kode_unit: "UMUM", nama_unit: "Subbagian Umum", jenis_unit: "pendukung" },
];

let MOCK_USERS: User[] = [
  // FIX: Changed username to nip to match type definition
  { id: 1, nama: "Dr. Ir. Harmanto, M.Eng.", nip: "harmanto", role: Role.PIMPINAN, unit_id: 4, status: 'aktif', foto: '' },
  { id: 2, nama: "Dr. Andy Saryoko, S.P., M.P.", nip: "andy", role: Role.WADIR, unit_id: 4, status: 'aktif', foto: '' },
  { id: 3, nama: "Mas Wisnu Aninditya, S.TP., M.Si.", nip: "wisnu", role: Role.ADMIN_UPM, unit_id: 5, status: 'aktif', foto: '' },
  { id: 10, nama: "Irwanto, S.Si., M.Pd.", nip: "irwanto", role: Role.AUDITOR, unit_id: 3, assignedUnits: ["TMP", "TAP"], status: 'aktif', foto: '' },
  { id: 12, nama: "Dr. Mardison S, S.TP., M.Si.", nip: "mardison", role: Role.AUDITOR, unit_id: 1, assignedUnits: ["THP", "TMP"], status: 'aktif', foto: '' },
  { id: 20, nama: "Dyah Ayu Shofiati (Shofie)", nip: "shofie", role: Role.ADMIN_PRODI, unit_id: 1, status: 'aktif', foto: '' },
  { id: 21, nama: "Rivani Yuniar, A.Md.P.", nip: "rivani", role: Role.ADMIN_PRODI, unit_id: 3, status: 'aktif', foto: '' },
  { id: 22, nama: "Rifari Satrio Sasongkojati (Satrio)", nip: "satrio", role: Role.ADMIN_PRODI, unit_id: 2, status: 'aktif', foto: '' },
  { id: 99, nama: "Super Admin SIAPI", nip: "superadmin", role: Role.SUPER_ADMIN, unit_id: 5, status: 'aktif', foto: '' },
];

let MOCK_FINDINGS: any[] = [
  { 
    id: 1, 
    uraian: 'Rasio jumlah dosen tetap terhadap jumlah mahasiswa (1:40) pada Prodi Teknologi Mekanisasi Pertanian tidak memenuhi standar minimal yang ditetapkan (1:30), berpotensi mengganggu kualitas bimbingan akademik dan praktikum.', 
    akar_masalah: 'Keterbatasan rekrutmen dosen tetap dan peningkatan jumlah penerimaan mahasiswa yang tidak diimbangi penambahan SDM.', 
    tindakan_koreksi: 'Mengajukan usulan rekrutmen 2 Dosen Tetap baru pada tahun anggaran berikutnya. Melakukan review dan optimalisasi beban mengajar dosen yang ada.', 
    level_risiko: RiskLevel.TINGGI, 
    unit: 'Prodi Teknologi Mekanisasi Pertanian', 
    standar: 'STD-04', 
    tipe: FindingType.MAJOR, 
    status_akhir: 'Proses RTL', 
    rencana_tindakan: 'Pihak prodi akan mengajukan surat permohonan penambahan Dosen Tetap ke Direktorat pada Q1 2025.', 
    tanggal_target_rtl: '2025-03-31', 
    bukti_rtl: null, 
    catatan_verifikasi: null, 
    status_verifikasi: 'Menunggu', 
    history: [
      { id: 102, user: 'Dyah Ayu Shofiati (Shofie)', role: Role.ADMIN_PRODI, action: 'Mengisi Rencana Tindak Lanjut.', timestamp: new Date(Date.now() - 3600000).toISOString() },
      { id: 101, user: 'Irwanto, S.Si., M.Pd.', role: Role.AUDITOR, action: 'Temuan dibuat.', timestamp: new Date(Date.now() - 7200000).toISOString() }
    ] 
  },
  { id: 2, uraian: 'Struktur organisasi dan tata pamong program studi belum terdokumentasi dengan jelas dan disosialisasikan.', akar_masalah: null, tindakan_koreksi: null, level_risiko: RiskLevel.SEDANG, unit: 'Prodi Tata Air Pertanian', standar: 'STD-02', tipe: FindingType.MINOR, status_akhir: 'Proses RTL', rencana_tindakan: 'Membuat SK Struktur Organisasi dan mengunggahnya di website prodi.', tanggal_target_rtl: '2024-11-15', bukti_rtl: null, catatan_verifikasi: null, status_verifikasi: 'Menunggu', history: [] },
  { id: 3, uraian: 'Bukti kegiatan PkM yang melibatkan partisipasi aktif mahasiswa belum terarsip dengan baik.', akar_masalah: null, tindakan_koreksi: null, level_risiko: RiskLevel.RENDAH, unit: 'Prodi Teknologi Hasil Pertanian', standar: 'STD-08', tipe: FindingType.OBS, status_akhir: 'Selesai', rencana_tindakan: 'Membuat folder Google Drive untuk arsip dokumentasi PkM.', tanggal_target_rtl: '2024-10-20', bukti_rtl: 'Screenshot_GDrive.png', catatan_verifikasi: 'Telah diperiksa dan folder sudah terstruktur dengan baik.', status_verifikasi: 'Sesuai', history: [] },
];

// Instruments for "Prodi Teknologi Mekanisasi Pertanian"
let MOCK_INSTRUMENTS: Instrument[] = [
    { id: 1, standard: 'STD-01', unit_target: 'Prodi Teknologi Mekanisasi Pertanian', pertanyaan: 'Apakah program studi memiliki kebijakan tertulis tentang visi, misi, tujuan, dan strategi (VMTS)?', bukti_wajib: 'SK Rektor/Dekan, Dokumen VMTS, Bukti Sosialisasi', doc_file: null, doc_status: DocumentStatus.MISSING },
    { id: 2, standard: 'STD-06', unit_target: 'Prodi Teknologi Mekanisasi Pertanian', pertanyaan: 'Apakah kurikulum program studi dirancang berbasis OBE (Outcome-Based Education)?', bukti_wajib: 'Dokumen Kurikulum, Laporan Tinjauan Kurikulum', doc_file: null, doc_status: DocumentStatus.MISSING },
    { id: 3, standard: 'STD-04', unit_target: 'Prodi Teknologi Mekanisasi Pertanian', pertanyaan: 'Apakah rasio jumlah dosen tetap terhadap jumlah mahasiswa sudah memadai?', bukti_wajib: 'Data PDDIKTI, Analisis Beban Kerja Dosen', doc_file: null, doc_status: DocumentStatus.MISSING },
    { id: 4, standard: 'STD-02', unit_target: 'Prodi Teknologi Mekanisasi Pertanian', pertanyaan: 'Apakah struktur organisasi dan tata pamong program studi terdokumentasi dengan jelas dan telah disosialisasikan?', bukti_wajib: 'Dokumen Struktur Organisasi, SK Jabatan, Uraian Tugas (Job Description)', doc_file: null, doc_status: DocumentStatus.MISSING },
    // Instruments for other units
    { id: 5, standard: 'STD-04', unit_target: 'Prodi Tata Air Pertanian', pertanyaan: 'Apakah jumlah dosen tetap memenuhi kebutuhan program studi?', bukti_wajib: 'Data PDDIKTI, Analisis Beban Kerja Dosen', doc_file: null, doc_status: DocumentStatus.MISSING },
];

// Auditee responses for "Prodi Teknologi Mekanisasi Pertanian"
let MOCK_AUDIT_RESPONSES: any[] = [
  { id: 1, instrument_id: 1, unit_id: 1, uploaded_file: 'VMTS_TMP_2024.pdf', answer_text: 'Dokumen VMTS terlampir sesuai dengan SK Rektor terbaru.', submitted_at: new Date().toISOString() },
  { id: 2, instrument_id: 2, unit_id: 1, uploaded_file: 'Kurikulum_OBE_TMP_2024.pdf', answer_text: 'Dokumen kurikulum OBE terlampir.', submitted_at: new Date().toISOString() },
  { id: 3, instrument_id: 3, unit_id: 1, uploaded_file: 'Data_Rasio_Dosen_Mahasiswa_TMP.xlsx', answer_text: 'Terlampir data rasio dosen dan mahasiswa per semester ganjil 2024.', submitted_at: new Date().toISOString() },
  { id: 4, instrument_id: 4, unit_id: 1, uploaded_file: 'Struktur_Organisasi_TMP.pdf', answer_text: 'Terlampir dokumen struktur organisasi, SK, dan Job Description.', submitted_at: new Date().toISOString() }
];

// Auditor scores for the responses
let MOCK_DESK_SCORES: any[] = [
  // Instrument 1 (VMTS): OK
  { id: 1, audit_response_id: 1, auditor_id: 10, score: 4, note: 'Sangat baik dan selaras dengan VMTS institusi.', status: DocumentStatus.APPROVED, doc_note: null, isComplete: true },
  { id: 2, audit_response_id: 1, auditor_id: 12, score: 4, note: 'Dokumen lengkap dan bukti sosialisasi memadai.', status: DocumentStatus.APPROVED, doc_note: null, isComplete: true },
  
  // Instrument 2 (OBE): Cukup
  { id: 3, audit_response_id: 2, auditor_id: 10, score: 3, note: 'Cukup baik, namun perlu perbaikan pada rubrik penilaian agar lebih sesuai dengan standar OBE.', status: DocumentStatus.APPROVED, doc_note: null, isComplete: true },
  { id: 4, audit_response_id: 2, auditor_id: 12, score: 3, note: 'Sudah berbasis OBE, tapi implementasi asesmen belum konsisten.', status: DocumentStatus.APPROVED, doc_note: null, isComplete: true },

  // Instrument 3 (RASIO DOSEN): **TRIGGER TEMUAN**
  { id: 5, audit_response_id: 3, auditor_id: 10, score: 1, note: 'Rasio tidak sesuai standar minimal, hanya 1:40 padahal syarat 1:30. Bukti terlampir mengkonfirmasi hal ini.', status: DocumentStatus.REJECTED, doc_note: 'Rasio Dosen-Mahasiswa tidak memenuhi syarat minimal.', isComplete: true },
  { id: 6, audit_response_id: 3, auditor_id: 12, score: 2, note: 'Data rasio tidak sinkron dengan data PDDIKTI. Perlu konfirmasi ulang dan perbaikan segera karena ini temuan major.', status: DocumentStatus.REJECTED, doc_note: 'Data rasio perlu disinkronkan dengan PDDIKTI.', isComplete: true },

  // Instrument 4 (Struktur Org): OK
  { id: 7, audit_response_id: 4, auditor_id: 10, score: 4, note: 'Struktur organisasi sudah sesuai dengan pedoman terbaru.', status: DocumentStatus.APPROVED, doc_note: null, isComplete: true },
  { id: 8, audit_response_id: 4, auditor_id: 12, score: 4, note: 'Sangat lengkap.', status: DocumentStatus.APPROVED, doc_note: null, isComplete: true }
];

// NEW: MOCK FOR SUBMISSION WORKFLOW STATUS
let MOCK_UNIT_SUBMISSION_STATUS: Record<string, UnitSubmissionStatus> = {
    "Prodi Teknologi Mekanisasi Pertanian": UnitSubmissionStatus.SUBMITTED,
    "Prodi Tata Air Pertanian": UnitSubmissionStatus.DRAFT,
    "Prodi Teknologi Hasil Pertanian": UnitSubmissionStatus.RETURNED,
};

const MOCK_STANDARDS_PEPI: Standard[] = [
  { id: 1, kode_standar: 'STD-01', nama_standar: 'Visi, Misi, Tujuan dan Strategi', kategori: 'Kriteria 1' },
  { id: 2, kode_standar: 'STD-02', nama_standar: 'Tata Pamong, Tata Kelola dan Kerjasama', kategori: 'Kriteria 2' },
  { id: 3, kode_standar: 'STD-03', nama_standar: 'Mahasiswa', kategori: 'Kriteria 3' },
  { id: 4, kode_standar: 'STD-04', nama_standar: 'Sumber Daya Manusia', kategori: 'Kriteria 4' },
  { id: 5, kode_standar: 'STD-05', nama_standar: 'Keuangan, Sarana dan Prasarana', kategori: 'Kriteria 5' },
  { id: 6, kode_standar: 'STD-06', nama_standar: 'Pendidikan', kategori: 'Kriteria 6' },
  { id: 7, kode_standar: 'STD-07', nama_standar: 'Penelitian', kategori: 'Kriteria 7' },
  { id: 8, kode_standar: 'STD-08', nama_standar: 'Pengabdian kepada Masyarakat', kategori: 'Kriteria 8' },
  { id: 9, kode_standar: 'STD-09', nama_standar: 'Luaran dan Capaian Tridharma', kategori: 'Kriteria 9' },
];

const MOCK_INITIAL_INSTRUMENT_BANK_PEPI: Record<string, { id: number, q: string, proof: string }[]> = {
  'STD-01': [ { id: 101, q: 'Apakah terdapat kebijakan tertulis Rektor/Dekan tentang visi, misi, tujuan dan strategi pencapaian beserta sosialisasinya?', proof: 'SK Rektor/Dekan, Dokumen VMTS, Bukti Sosialisasi (Notulen/Daftar Hadir)' }, { id: 102, q: 'Bagaimana kesesuaian VMTS Prodi dengan VMTS UPPS dan PT? Jelaskan mekanisme penyusunannya.', proof: 'Matriks Kesesuaian VMTS, Berita Acara Penyusunan' }, ], 'STD-02': [ { id: 201, q: 'Apakah struktur organisasi dan tata pamong program studi terdokumentasi dengan jelas?', proof: 'Dokumen Struktur Organisasi, SK Jabatan, Uraian Tugas (Job Description).' }, ], 'STD-03': [], 'STD-04': [], 'STD-05': [], 'STD-06': [], 'STD-07': [], 'STD-08': [], 'STD-09': [],
};

const MOCK_STANDARDS_UNGGUL: Standard[] = [
    { id: 101, kode_standar: 'STD-01', nama_standar: 'Budaya Mutu dan PPEPP', kategori: 'Unggul 2025' },
    { id: 102, kode_standar: 'STD-02', nama_standar: 'Relevansi Pendidikan (Kurikulum OBE)', kategori: 'Unggul 2025' },
    { id: 103, kode_standar: 'STD-03', nama_standar: 'Sarana Pembelajaran dan Laboratorium Vokasi', kategori: 'Unggul 2025' },
    { id: 104, kode_standar: 'STD-04', nama_standar: 'Proses Pembelajaran dan Penilaian', kategori: 'Unggul 2025' },
    { id: 105, kode_standar: 'STD-05', nama_standar: 'Sumber Daya Manusia (Dosen & Tendik)', kategori: 'Unggul 2025' },
    { id: 106, kode_standar: 'STD-06', nama_standar: 'Mahasiswa dan Lulusan (Output & Outcome)', kategori: 'Unggul 2025' },
    { id: 107, kode_standar: 'STD-07', nama_standar: 'Keunggulan dan Diferensiasi Prodi', kategori: 'Unggul 2025' },
];

const MOCK_INITIAL_INSTRUMENT_BANK_UNGGUL: Record<string, { id: number, q: string, proof: string }[]> = {
    'STD-01': [
        { id: 1001, q: 'Apakah Program Studi melaksanakan siklus PPEPP (Penetapan, Pelaksanaan, Evaluasi, Pengendalian, dan Peningkatan) secara lengkap dan berkelanjutan pada seluruh aspek akademik dan non-akademik Prodi?', proof: 'Manual SPMI Prodi, standar mutu Prodi, laporan PPEPP' },
        { id: 1002, q: 'Apakah hasil Evaluasi dan Audit Mutu Internal (AMI) ditindaklanjuti dengan rencana perbaikan yang terdokumentasi dan dilaksanakan?', proof: 'Laporan AMI, RTM Prodi, matriks tindak lanjut' },
        { id: 1003, q: 'Apakah terdapat bukti peningkatan mutu berkelanjutan (continuous improvement) dalam kurun waktu minimal 3 tahun terakhir?', proof: 'Rekap AMI 3 tahun, grafik tren, laporan peningkatan' },
        { id: 1004, q: 'Apakah budaya mutu telah menjadi bagian dari tata kelola Prodi, tercermin dalam kebijakan, SOP, dan pengambilan keputusan?', proof: 'SOP Prodi, notulen rapat, SK keputusan Prodi' },
    ],
    'STD-02': [
        { id: 2001, q: 'Apakah kurikulum Prodi D3 disusun berbasis Outcome-Based Education (OBE) dengan mengacu pada profil lulusan, CPL, dan KKNI/SKKNI?', proof: 'Dokumen kurikulum OBE, CPL Prodi' },
        { id: 2002, q: 'Apakah proses penyusunan kurikulum melibatkan pemangku kepentingan eksternal (industri pertanian, pengguna lulusan, alumni)?', proof: 'Notulen FGD, daftar hadir, dokumentasi' },
        { id: 2003, q: 'Apakah struktur kurikulum menunjukkan dominasi pembelajaran praktik, proyek, dan kasus lapangan yang relevan dengan enjiniring pertanian?', proof: 'Struktur kurikulum, RPS, modul praktikum' },
        { id: 2004, q: 'Apakah kurikulum mengintegrasikan isu keberlanjutan dan SDGs yang relevan dengan sektor pertanian?', proof: 'Dokumen kurikulum, RPS terkait' },
        { id: 2005, q: 'Apakah capaian pembelajaran lulusan (CPL) diukur, dianalisis, dan digunakan untuk perbaikan kurikulum?', proof: 'Laporan evaluasi CPL, RTM kurikulum' },
    ],
    'STD-03': [
        { id: 3001, q: 'Apakah Prodi memiliki laboratorium/bengkel/alsintan yang mendukung kompetensi inti lulusan D3 enjiniring pertanian?', proof: 'SK laboratorium, daftar sarpras' },
        { id: 3002, q: 'Apakah tersedia standar pengelolaan laboratorium, termasuk SOP, jadwal, dan penanggung jawab?', proof: 'SOP lab, SK pengelola' },
        { id: 3003, q: 'Apakah tersedia instrumen dan modul praktikum yang digunakan secara konsisten dalam pembelajaran?', proof: 'Modul praktikum, logbook' },
        { id: 3004, q: 'Apakah terdapat bukti sahih penggunaan laboratorium dalam pembelajaran dan evaluasi hasil praktikum?', proof: 'Jadwal praktikum, foto kegiatan' },
        { id: 3005, q: 'Apakah dilakukan evaluasi dan peningkatan sarana pembelajaran berbasis kebutuhan CPL?', proof: 'Laporan evaluasi sarpras, tindak lanjut' },
    ],
    'STD-04': [
        { id: 4001, q: 'Apakah seluruh mata kuliah memiliki RPS berbasis OBE yang memuat CPL, CPMK, sub-CPMK, metode, dan penilaian?', proof: 'RPS OBE' },
        { id: 4002, q: 'Apakah metode pembelajaran yang diterapkan aktif dan kontekstual (PBL, PjBL, praktikum lapangan)?', proof: 'RPS, laporan pembelajaran' },
        { id: 4003, q: 'Apakah sistem penilaian mengukur capaian pembelajaran, bukan hanya kehadiran atau ujian tertulis?', proof: 'Rubrik penilaian, contoh asesmen' },
        { id: 4004, q: 'Apakah hasil penilaian pembelajaran dievaluasi dan ditindaklanjuti untuk peningkatan mutu pembelajaran?', proof: 'Laporan evaluasi pembelajaran' },
    ],
    'STD-05': [
        { id: 5001, q: 'Apakah jumlah dan kualifikasi DTPS memadai dan relevan dengan kebutuhan Prodi D3 vokasi?', proof: 'Data DTPS, ijazah, NIDN' },
        { id: 5002, q: 'Apakah dosen memiliki kompetensi praktis/industri sesuai bidang enjiniring pertanian?', proof: 'Sertifikat, pengalaman industri' },
        { id: 5003, q: 'Apakah tenaga kependidikan mendukung kegiatan praktikum dan layanan akademik Prodi?', proof: 'Data tendik, uraian tugas' },
        { id: 5004, q: 'Apakah terdapat program peningkatan kompetensi SDM yang terencana dan dievaluasi?', proof: 'Roadmap SDM, laporan pelatihan' },
    ],
    'STD-06': [
        { id: 6001, q: 'Apakah persentase kelulusan tepat masa tempuh atau ≤2x masa studi memenuhi ambang unggul LAM PTIP untuk D3?', proof: 'Data kelulusan PD-Dikti' },
        { id: 6002, q: 'Apakah rata-rata waktu tunggu lulusan bekerja ≤ 3,5 bulan?', proof: 'Tracer study tervalidasi' },
        { id: 6003, q: 'Apakah pekerjaan lulusan relevan dengan bidang enjiniring pertanian?', proof: 'Analisis tracer study' },
        { id: 6004, q: 'Apakah hasil tracer study digunakan untuk perbaikan kurikulum dan pembelajaran?', proof: 'Notulen evaluasi kurikulum' },
    ],
    'STD-07': [
        { id: 7001, q: 'Apakah Prodi memiliki kekhasan/keunggulan vokasi yang membedakan dari Prodi sejenis?', proof: 'Dokumen keunggulan Prodi' },
        { id: 7002, q: 'Apakah keunggulan tersebut diimplementasikan dalam kurikulum dan pembelajaran?', proof: 'RPS khas, modul khusus' },
        { id: 7003, q: 'Apakah Prodi menghasilkan luaran vokasi nyata (produk, prototipe, jasa teknis, inovasi alsintan)?', proof: 'Dokumentasi produk, laporan' },
        { id: 7004, q: 'Apakah keunggulan Prodi berdampak pada kualitas lulusan dan pengakuan eksternal?', proof: 'Kerja sama, testimoni pengguna' },
    ]
};


// --- Auth ---
export async function login(nip: string, password: string): Promise<{ user: User, unit?: Unit }> {
  try {
    const response = await fetch(`${API_BASE_URL}/login/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: nip, password }), // Backend uses 'username'
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.detail || `Login gagal: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    // Store tokens for session management
    localStorage.setItem('access_token', data.access);
    localStorage.setItem('refresh_token', data.refresh);

    // Return the structure expected by AuthContext
    return { user: data.user, unit: data.unit };

  } catch (error) {
    if (error instanceof TypeError) { // Network error or CORS
        console.warn("API: login Error, falling back to mock data.", error);
        await new Promise(r => setTimeout(r, API_DELAY));
        
        // Mock data logic remains the same
        // FIX: Changed user.nip to user.username to align with Django model and User type
        const foundUser = MOCK_USERS.find(u => u.nip.toLowerCase() === nip.toLowerCase());
        if (!foundUser) throw new Error("User tidak ditemukan.");
        if (password !== 'pepi123') throw new Error("Password salah.");
        const foundUnit = MOCK_UNITS.find(unit => unit.id === foundUser.unit_id);
        return { user: foundUser, unit: foundUnit };
    }
    throw error;
  }
}

// --- Dashboard & Logs ---
export async function getDashboardData(unitCode: UnitCode, user: CurrentUser | null): Promise<DashboardData | null> {
    await new Promise(r => setTimeout(r, API_DELAY)); // Simulate network delay

    try {
        const allUnits = await getUnits();
        const allInstruments = await getInstruments();
        const allFindings = await getFindings();

        const targetUnit = allUnits.find(u => u.kode_unit === unitCode);
        if (!targetUnit) {
            console.warn(`Dashboard data generation failed: Unit with code ${unitCode} not found.`);
            return null;
        }
        const unitName = targetUnit.nama_unit;

        const unitInstruments = allInstruments.filter(i => i.unit_target === unitName);
        const unitFindings = allFindings.filter(f => f.unit === unitName);
        
        // --- CALCULATIONS ---

        // 1. STATS
        const total_findings = unitFindings.length;
        const major_findings = unitFindings.filter(f => f.tipe === FindingType.MAJOR).length;
        const minor_findings = unitFindings.filter(f => f.tipe === FindingType.MINOR).length;

        // 2. RADAR & AVERAGE SCORE
        const scoresByCriteria: { [key: string]: number[] } = {};
        unitInstruments.forEach(inst => {
            const stdCode = inst.standard.startsWith('STD-') ? inst.standard : `STD-${inst.standard.padStart(2, '0')}`;
            if (!scoresByCriteria[stdCode]) {
                scoresByCriteria[stdCode] = [];
            }
            if (inst.evaluations && inst.auditor_ids) {
                const [id1, id2] = inst.auditor_ids;
                // FIX: Use string index for evaluations object
                const score1 = inst.evaluations[String(id1)]?.skor_desk;
                const score2 = inst.evaluations[String(id2)]?.skor_desk;
                if (score1 !== undefined && score2 !== undefined) {
                    scoresByCriteria[stdCode].push((score1 + score2) / 2);
                }
            } else if (inst.skor_desk !== undefined && inst.skor_desk !== null) {
                scoresByCriteria[stdCode].push(inst.skor_desk);
            }
        });

        const KRITERIA_MAP: Record<string, string> = { "STD-01": "K1", "STD-02": "K2", "STD-03": "K3", "STD-04": "K4", "STD-05": "K5", "STD-06": "K6", "STD-07": "K7", "STD-08": "K8", "STD-09": "K9" };
        
        const radar: { criteria: string, score: number }[] = Object.entries(KRITERIA_MAP).map(([std, k]) => {
            const scores = scoresByCriteria[std];
            const avgScore = scores && scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
            return { criteria: k, score: parseFloat(avgScore.toFixed(2)) };
        });

        const totalScores = radar.map(r => r.score).filter(s => s > 0);
        const average_score = totalScores.length > 0 ? totalScores.reduce((a, b) => a + b, 0) / totalScores.length : 0;
        
        // 3. COMPOSITION
        const totalInstrumentsCount = unitInstruments.length;
        let patuhCount = 0;
        let patuhBersyaratCount = 0;
        let tidakPatuhCount = 0;

        unitInstruments.forEach(inst => {
            let aggregateStatus = inst.doc_status || DocumentStatus.MISSING;
            if (inst.evaluations && inst.auditor_ids) {
                const [id1, id2] = inst.auditor_ids;
                const status1 = inst.evaluations[String(id1)]?.status;
                const status2 = inst.evaluations[String(id2)]?.status;
                if (status1 === DocumentStatus.REJECTED || status2 === DocumentStatus.REJECTED) {
                    aggregateStatus = DocumentStatus.REJECTED;
                } else if (status1 === DocumentStatus.APPROVED && status2 === DocumentStatus.APPROVED) {
                    aggregateStatus = DocumentStatus.APPROVED;
                } else if (status1 === DocumentStatus.UPLOADED || status2 === DocumentStatus.UPLOADED) {
                    aggregateStatus = DocumentStatus.UPLOADED;
                }
            }

            switch (aggregateStatus) {
                case DocumentStatus.APPROVED: patuhCount++; break;
                case DocumentStatus.UPLOADED: patuhBersyaratCount++; break;
                default: tidakPatuhCount++; break;
            }
        });

        const valuePatuh = totalInstrumentsCount > 0 ? Math.round((patuhCount / totalInstrumentsCount) * 100) : 0;
        const valueBersyarat = totalInstrumentsCount > 0 ? Math.round((patuhBersyaratCount / totalInstrumentsCount) * 100) : 0;
        
        const composition = [
          { name: "Patuh", value: valuePatuh, color: '#10b981' },
          { name: "Patuh Bersyarat", value: valueBersyarat, color: '#f59e0b' },
          { name: "Tidak Patuh", value: 100 - valuePatuh - valueBersyarat, color: '#ef4444' },
        ];

        // 4. TRENDS (Dynamically generated)
        const trends = [
          { period: "2022", findings: total_findings + Math.floor(Math.random() * 5) + 3 },
          { period: "2023", findings: total_findings + Math.floor(Math.random() * 2) + 1 },
          { period: "2024", findings: total_findings },
        ];

        return {
            stats: { average_score, total_findings, major_findings, minor_findings },
            radar,
            composition,
            trends
        };

    } catch (error) {
        console.error("Failed to generate dashboard data from API/mocks:", error);
        throw new Error("Gagal mengagregasi data dashboard.");
    }
}

export async function getActivityLog(): Promise<ActivityLogItem[]> {
    await new Promise(r => setTimeout(r, API_DELAY));
    return [];
}

// --- Master Data ---
export async function getUsers(): Promise<User[]> {
  try {
    const response = await fetch(`${API_BASE_URL}/users/`);
    if (!response.ok) throw new Error("Gagal mengambil data pengguna dari server.");
    const data = await response.json();
    const parsedData = data.map((user: any) => ({
      ...user,
      assignedUnits: typeof user.assignedUnits === 'string' ? JSON.parse(user.assignedUnits) : user.assignedUnits,
    }));
    MOCK_USERS = parsedData; // Sync mock data
    return parsedData;
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn("API: getUsers Error, falling back to mock data.", error);
        await new Promise(r => setTimeout(r, API_DELAY));
        return MOCK_USERS;
    }
    throw error;
  }
}

export async function saveUser(user: Partial<User>): Promise<User> {
  try {
    const isEditing = !!user.id;
    const url = isEditing ? `${API_BASE_URL}/users/${user.id}/` : `${API_BASE_URL}/users/`;
    const method = isEditing ? 'PUT' : 'POST';
    const body = { ...user };
    
    if ('password' in body && !body.password) {
        delete body.password;
    }
    if (!isEditing) {
        delete body.id; // Django will assign an ID on creation
    }

    const response = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(JSON.stringify(errorData) || 'Gagal menyimpan data pengguna ke server.');
    }
    return await response.json();
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn("API: saveUser failed, falling back to mock update.", error);
        await new Promise(r => setTimeout(r, API_DELAY));
        
        const isEditing = typeof user.id === 'number' && MOCK_USERS.some(u => u.id === user.id);

        if (isEditing) {
          let updatedUser: User | undefined;
          MOCK_USERS = MOCK_USERS.map(u => {
            if (u.id === user.id) {
              updatedUser = { ...u, ...user };
              return updatedUser;
            }
            return u;
          });
          if (!updatedUser) throw new Error("Mock user not found for update");
          return updatedUser;
        } else {
          const newUser: User = { id: Date.now(), status: 'aktif', nama: '', nip: '', role: Role.AUDITEE, ...user } as User;
          MOCK_USERS.push(newUser);
          return newUser;
        }
    }
    throw error;
  }
}

export async function deleteUser(userId: number): Promise<void> {
  try {
    const response = await fetch(`${API_BASE_URL}/users/${userId}/`, { method: 'DELETE' });
    if (response.status !== 204) throw new Error(`Gagal menghapus. Status: ${response.status}`);
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn("API: deleteUser failed, using mock update.", error);
        await new Promise(r => setTimeout(r, API_DELAY));
        MOCK_USERS = MOCK_USERS.filter(u => u.id !== userId);
        return;
    }
    throw error;
  }
}

export async function getUnits(): Promise<Unit[]> {
  try {
    const response = await fetch(`${API_BASE_URL}/units/`);
    if (!response.ok) throw new Error(`Gagal mengambil data unit: ${response.statusText}`);
    const data: Unit[] = await response.json();
    MOCK_UNITS = data; // Sync mock data
    return data;
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn("API: getUnits Error, falling back to mock data.", error);
        await new Promise(r => setTimeout(r, API_DELAY));
        return MOCK_UNITS;
    }
    throw error;
  }
}

export async function saveUnit(unit: Partial<Unit>): Promise<Unit> {
  try {
    const isEditing = !!unit.id;
    const url = isEditing ? `${API_BASE_URL}/units/${unit.id}/` : `${API_BASE_URL}/units/`;
    const method = isEditing ? 'PUT' : 'POST';
    const body = { ...unit };
    if (!isEditing) delete body.id;

    const response = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!response.ok) throw new Error(JSON.stringify(await response.json()));
    return await response.json();
  } catch (error) {
    if (error instanceof TypeError) {
      console.warn("API: saveUnit failed, falling back to mock update.", error);
      await new Promise(r => setTimeout(r, API_DELAY));
      
      const isEditing = typeof unit.id === 'number' && MOCK_UNITS.some(u => u.id === unit.id);

      if (isEditing) {
        let updatedUnit: Unit | undefined;
        MOCK_UNITS = MOCK_UNITS.map(u => {
          if (u.id === unit.id) {
            updatedUnit = { ...u, ...unit } as Unit;
            return updatedUnit;
          }
          return u;
        });
        if (!updatedUnit) throw new Error("Mock unit not found for update");
        return updatedUnit;
      } else {
        const newUnit = { id: Date.now(), ...unit } as Unit;
        MOCK_UNITS.push(newUnit);
        return newUnit;
      }
    }
    throw error;
  }
}

export async function deleteUnit(unitId: number): Promise<void> {
  try {
    const response = await fetch(`${API_BASE_URL}/units/${unitId}/`, { method: 'DELETE' });
    if (response.status !== 204) throw new Error(`Gagal menghapus. Status: ${response.status}`);
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn("API: deleteUnit failed, using mock update.", error);
        await new Promise(r => setTimeout(r, API_DELAY));
        MOCK_UNITS = MOCK_UNITS.filter(u => u.id !== unitId);
        return;
    }
    throw error;
  }
}

// --- Findings ---
export async function getFindings(): Promise<any[]> {
  try {
    const response = await fetch(`${API_BASE_URL}/findings/`);
    if (!response.ok) throw new Error("Gagal mengambil data temuan dari server.");
    const data = await response.json();
    MOCK_FINDINGS = data; // Sync
    return data;
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn("API: getFindings Error, falling back to mock data.", error);
        await new Promise(r => setTimeout(r, API_DELAY));
        return MOCK_FINDINGS;
    }
    throw error;
  }
}

export async function saveFinding(finding: any): Promise<any> {
  try {
    const isEditing = !!finding.id && typeof finding.id === 'number';
    const url = isEditing ? `${API_BASE_URL}/findings/${finding.id}/` : `${API_BASE_URL}/findings/`;
    const method = isEditing ? 'PUT' : 'POST';
    const payload = {...finding};
    if (!isEditing) delete payload.id;
    const response = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!response.ok) throw new Error(JSON.stringify(await response.json()));
    return await response.json();
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn(`API: saveFinding failed, using mock update.`, error);
        await new Promise(r => setTimeout(r, API_DELAY));
        const isEditing = !!finding.id && MOCK_FINDINGS.some(f => f.id === finding.id);
        if (isEditing) {
          MOCK_FINDINGS = MOCK_FINDINGS.map(f => f.id === finding.id ? { ...f, ...finding } : f);
          return MOCK_FINDINGS.find(f => f.id === finding.id);
        } else {
          const newFinding = { ...finding, id: Date.now() };
          MOCK_FINDINGS.push(newFinding);
          return newFinding;
        }
    }
    throw error;
  }
}

export async function deleteFinding(findingId: number): Promise<void> {
  try {
    const response = await fetch(`${API_BASE_URL}/findings/${findingId}/`, { method: 'DELETE' });
    if (response.status !== 204) throw new Error("Gagal menghapus temuan dari server.");
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn("API: deleteFinding failed, using mock update.", error);
        await new Promise(r => setTimeout(r, API_DELAY));
        MOCK_FINDINGS = MOCK_FINDINGS.filter(f => f.id !== findingId);
    } else {
        throw error;
    }
  }
}

export async function analyzeFindingAI(uraian: string): Promise<any> {
    try {
        const response = await fetch(`${API_BASE_URL}/analyze-finding/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ uraian }),
        });
        if (!response.ok) throw new Error("Analisis AI gagal. Backend mungkin mengalami masalah.");
        return await response.json();
    } catch (error) {
        console.error("API: AnalyzeFindingAI Error:", error);
        if (error instanceof TypeError) {
          throw new Error("Tidak dapat terhubung ke layanan AI. Periksa koneksi backend.");
        }
        throw error;
    }
}

// --- Instruments & Planning ---
export async function getStandards(type: 'standar' | 'unggul' = 'standar'): Promise<Standard[]> {
    await new Promise(r => setTimeout(r, 100));
    return type === 'unggul' ? MOCK_STANDARDS_UNGGUL : MOCK_STANDARDS_PEPI;
}

export async function getInstrumentBank(type: 'standar' | 'unggul' = 'standar'): Promise<Record<string, any[]>> {
    await new Promise(r => setTimeout(r, 200));
    const key = type === 'unggul' ? 'siapepi_instrument_bank_unggul' : 'siapepi_instrument_bank_pepi';
    const defaultBank = type === 'unggul' ? MOCK_INITIAL_INSTRUMENT_BANK_UNGGUL : MOCK_INITIAL_INSTRUMENT_BANK_PEPI;
    
    const savedBank = localStorage.getItem(key);
    if (savedBank) {
        return JSON.parse(savedBank);
    }
    localStorage.setItem(key, JSON.stringify(defaultBank));
    return defaultBank;
}

export async function saveInstrumentBank(bank: Record<string, any[]>, type: 'standar' | 'unggul' = 'standar'): Promise<void> {
    await new Promise(r => setTimeout(r, 300));
    const key = type === 'unggul' ? 'siapepi_instrument_bank_unggul' : 'siapepi_instrument_bank_pepi';
    localStorage.setItem(key, JSON.stringify(bank));
}

export async function getInstruments(): Promise<Instrument[]> {
  try {
    const response = await fetch(`${API_BASE_URL}/instruments/`);
    if (!response.ok) throw new Error("Gagal mengambil data instrumen dari server.");
    const data = await response.json();
    MOCK_INSTRUMENTS = data; // Sync
    return data;
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn("API: getInstruments Error, falling back to mock data.", error);
        await new Promise(r => setTimeout(r, API_DELAY));
        return MOCK_INSTRUMENTS;
    }
    throw error;
  }
}

export async function saveInstrument(instrument: Partial<Instrument>): Promise<Instrument> {
  try {
    const isEditing = typeof instrument.id === 'number' && instrument.id > 0;
    const method = isEditing ? 'PUT' : 'POST';
    const url = isEditing ? `${API_BASE_URL}/instruments/${instrument.id}/` : `${API_BASE_URL}/instruments/`;
    const body = { ...instrument };
    if (!isEditing) delete body.id;
    const response = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!response.ok) throw new Error(JSON.stringify(await response.json()));
    return await response.json();
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn(`API: saveInstrument failed, using mock update.`, error);
        await new Promise(r => setTimeout(r, API_DELAY));
        const isEditing = typeof instrument.id === 'number' && MOCK_INSTRUMENTS.some(i => i.id === instrument.id);
        if (isEditing) {
          MOCK_INSTRUMENTS = MOCK_INSTRUMENTS.map(i => i.id === instrument.id ? { ...i, ...instrument } as Instrument : i);
          return MOCK_INSTRUMENTS.find(i => i.id === instrument.id) as Instrument;
        } else {
          const newInstrument = { ...instrument, id: Date.now() } as Instrument;
          MOCK_INSTRUMENTS.push(newInstrument);
          return newInstrument;
        }
    }
    throw error;
  }
}

export async function deleteInstrument(instrumentId: number): Promise<void> {
  try {
    const response = await fetch(`${API_BASE_URL}/instruments/${instrumentId}/`, { method: 'DELETE' });
    if (response.status !== 204) throw new Error(`Gagal menghapus. Status: ${response.status}`);
  } catch (error) {
    if (error instanceof TypeError) {
        console.warn("API: deleteInstrument failed, using mock update.", error);
        await new Promise(r => setTimeout(r, API_DELAY));
        MOCK_INSTRUMENTS = MOCK_INSTRUMENTS.filter(i => i.id !== instrumentId);
    } else {
        throw error;
    }
  }
}

// --- NEW DESK EVALUATION & SUBMISSION ENDPOINTS ---

export async function getSubmissionStatus(unitName: string): Promise<UnitSubmissionStatus> {
    await new Promise(r => setTimeout(r, 100));
    return MOCK_UNIT_SUBMISSION_STATUS[unitName] || UnitSubmissionStatus.DRAFT;
}

export async function setSubmissionStatus(unitName: string, status: UnitSubmissionStatus): Promise<void> {
    await new Promise(r => setTimeout(r, 300));
    MOCK_UNIT_SUBMISSION_STATUS[unitName] = status;
}

export async function getDeskEvaluationInstruments(unitName: string): Promise<Instrument[]> {
  await new Promise(r => setTimeout(r, API_DELAY));
  try {
    const unitInstruments = MOCK_INSTRUMENTS.filter(i => i.unit_target === unitName);
    const mockAuditor1Id = 10;
    const mockAuditor2Id = 12;

    // Simulate nested serialization from backend
    return unitInstruments.map(inst => {
      const response = MOCK_AUDIT_RESPONSES.find(r => r.instrument_id === inst.id);
      if (!response) {
        return {
          ...inst,
          auditor_ids: [mockAuditor1Id, mockAuditor2Id],
          evaluations: {
            [String(mockAuditor1Id)]: { status: DocumentStatus.MISSING, isComplete: false },
            [String(mockAuditor2Id)]: { status: DocumentStatus.MISSING, isComplete: false },
          }
        };
      }
      
      const scores = MOCK_DESK_SCORES.filter(s => s.audit_response_id === response.id);
      
      const evaluations: { [key: string]: any } = {};
      const instrumentAuditorIds = inst.auditor_ids || [mockAuditor1Id, mockAuditor2Id];

      instrumentAuditorIds.forEach(auditorId => {
        const score = scores.find(s => s.auditor_id === auditorId);
        evaluations[String(auditorId)] = {
          status: score ? score.status : DocumentStatus.UPLOADED,
          skor_desk: score?.score,
          catatan_desk: score?.note,
          doc_note: score?.doc_note,
          isComplete: score?.isComplete || false,
        };
      });
      
      return {
        ...inst,
        auditor_ids: instrumentAuditorIds as [number, number],
        jawaban_auditee: response?.answer_text,
        doc_file: response?.uploaded_file,
        doc_status: evaluations[String(instrumentAuditorIds?.[0])]?.status || DocumentStatus.UPLOADED,
        evaluations: evaluations,
        audit_response_id: response?.id 
      };
    });
  } catch (error) {
    console.error("API: getDeskEvaluationInstruments failed:", error);
    throw error;
  }
}

export async function submitAuditResponse(payload: { instrument_id: number; unit_name: string; answer_text?: string; uploaded_file?: string }): Promise<any> {
  await new Promise(r => setTimeout(r, API_DELAY));
  let response = MOCK_AUDIT_RESPONSES.find(r => r.instrument_id === payload.instrument_id);
  const unit = MOCK_UNITS.find(u => u.nama_unit === payload.unit_name);

  if (response) {
    if (payload.answer_text !== undefined) response.answer_text = payload.answer_text;
    if (payload.uploaded_file) response.uploaded_file = payload.uploaded_file;
    response.submitted_at = new Date().toISOString();
  } else {
    response = { id: Date.now(), instrument_id: payload.instrument_id, unit_id: unit?.id, answer_text: payload.answer_text, uploaded_file: payload.uploaded_file, submitted_at: new Date().toISOString() };
    MOCK_AUDIT_RESPONSES.push(response);
  }
  
  MOCK_INSTRUMENTS = MOCK_INSTRUMENTS.map(i => {
    if (i.id === payload.instrument_id) {
      return { ...i, doc_status: DocumentStatus.UPLOADED, doc_file: response.uploaded_file, jawaban_auditee: response.answer_text };
    }
    return i;
  });

  return response;
}

export async function submitDeskScore(payload: { audit_response_id: number; auditor_id: number; score?: number; note?: string; status?: DocumentStatus; doc_note?: string; isComplete?: boolean }): Promise<any> {
    await new Promise(r => setTimeout(r, API_DELAY));
    let score = MOCK_DESK_SCORES.find(s => s.audit_response_id === payload.audit_response_id && s.auditor_id === payload.auditor_id);
    if (score) {
        const updatedScore = { ...score, ...payload };
        MOCK_DESK_SCORES = MOCK_DESK_SCORES.map(s => (s.id === score.id ? updatedScore : s));
        score = updatedScore;
    } else {
        score = { id: Date.now(), ...payload };
        MOCK_DESK_SCORES.push(score);
    }
    return score;
}

export async function getDeskEvaluationCompleteness(unitName: string): Promise<any> {
    await new Promise(r => setTimeout(r, API_DELAY));
    const instrumentsForUnit = MOCK_INSTRUMENTS.filter(i => i.unit_target === unitName);
    if (instrumentsForUnit.length === 0) return { total_instruments: 0, incomplete_ids: [], is_complete: true };
    
    const incomplete_ids: number[] = [];
    instrumentsForUnit.forEach(inst => {
        const response = MOCK_AUDIT_RESPONSES.find(r => r.instrument_id === inst.id);
        if (!response || !inst.auditor_ids) {
            incomplete_ids.push(inst.id);
            return;
        }
        const scores = MOCK_DESK_SCORES.filter(s => s.audit_response_id === response.id);
        if (scores.length < inst.auditor_ids.length) {
            incomplete_ids.push(inst.id);
        }
    });

    return { total_instruments: instrumentsForUnit.length, incomplete_ids, is_complete: incomplete_ids.length === 0 };
}


// --- OTHER STUBS ---
export async function getProdiProfiles(): Promise<UnitProfile[]> { return []; }
export async function getUPMStructure(): Promise<any | null> { return null; }
export async function getAuditors(): Promise<AuditorProfile[]> { return []; }
export async function getStandardDocuments(): Promise<StandardDocument[]> { return []; }
export async function getRtmData(): Promise<any | null> { return null; }
export async function saveRtmData(data: any): Promise<any> { return data; }
export async function saveDeskEvaluation(instrumentId: number, evaluation: any): Promise<Partial<Instrument>> {
  await new Promise(r => setTimeout(r, 250));
  return { id: instrumentId, ...evaluation };
}