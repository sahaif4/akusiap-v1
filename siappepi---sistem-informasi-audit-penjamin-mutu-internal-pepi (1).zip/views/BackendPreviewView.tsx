import React, { useState } from 'react';
import { 
  Terminal, Play, Database, Cpu, Layers, Copy, Network, CheckCircle2, FolderCog, ShieldCheck, LucideIcon
} from 'lucide-react';

const BackendPreviewView: React.FC = () => {
  const [activeTab, setActiveTab] = useState('models');

  const codeSnippets = {
    models: `# audit_app/models.py (VERSI IDEAL PEPI)
from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    nip = models.CharField(max_length=50, unique=True)
    role = models.CharField(max_length=50)
    unit = models.ForeignKey('Unit', on_delete=models.SET_NULL, null=True)

class AuditResponse(models.Model):
    cycle = models.ForeignKey('AuditCycle', on_delete=models.CASCADE)
    unit = models.ForeignKey('Unit', on_delete=models.CASCADE)
    instrument = models.ForeignKey('Instrument', on_delete=models.CASCADE)
    file_bukti = models.FileField(upload_to='audit_evidence/')

class DeskEvaluation(models.Model):
    # Mendukung skema Dual-Auditor per instrumen
    audit_response = models.ForeignKey(AuditResponse, on_delete=models.CASCADE)
    auditor = models.ForeignKey(User, on_delete=models.CASCADE)
    skor = models.IntegerField()
    is_complete = models.BooleanField(default=False)
`,
    logic: `# Logic Konsensus Dual-Auditor
def get_consensus_score(response_id):
    evals = DeskEvaluation.objects.filter(audit_response_id=response_id, is_complete=True)
    if evals.count() < 2:
        return None # Menunggu auditor kedua
    
    scores = [e.skor for e in evals]
    if abs(scores[0] - scores[1]) > 1:
        return "KONFLIK" # Memerlukan rekonsiliasi UPM
    return sum(scores) / 2
`,
    setup: `# siapepi_backend/settings.py
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'db_siapepi',
        'USER': 'root',
        'PASSWORD': '',
        'HOST': '127.0.0.1',
    }
}
AUTH_USER_MODEL = 'audit_app.User'
`,
  };

  const tabs: { id: string; label: string; icon: LucideIcon }[] = [
    { id: 'models', label: '1. Models PPEPP', icon: Database },
    { id: 'logic', label: '2. Logic Konsensus', icon: Network },
    { id: 'setup', label: '3. DB Setup', icon: FolderCog },
  ];

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-500">
      <div className="bg-slate-900 text-white p-10 rounded-[3rem] shadow-2xl relative overflow-hidden border border-slate-800">
         <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-[100px] -mr-20 -mt-20"></div>
         <div className="relative z-10">
            <h2 className="text-3xl font-black uppercase tracking-tighter mb-2">Backend Architecture Blueprint</h2>
            <p className="text-slate-400 text-sm max-w-2xl font-medium leading-relaxed">
               Skema database Django yang dioptimalkan untuk siklus PPEPP dan transparansi penilaian dual-auditor.
            </p>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-1 space-y-2">
           {tabs.map((item) => {
             const Icon = item.icon;
             return (
               <button 
                 key={item.id} 
                 onClick={() => setActiveTab(item.id)} 
                 className={`w-full flex items-center gap-3 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                   activeTab === item.id 
                     ? 'bg-pepi-green-900 text-white shadow-xl shadow-pepi-green-100' 
                     : 'bg-white text-slate-500 hover:bg-slate-100 border border-slate-200'
                 }`}
               >
                 <Icon size={16} /> {item.label}
               </button>
             );
           })}
        </div>

        <div className="lg:col-span-4">
           <div className="bg-slate-900 rounded-[2.5rem] border border-slate-800 shadow-2xl overflow-hidden">
              <div className="px-8 py-4 bg-slate-800/50 border-b border-slate-800 flex justify-between items-center">
                 <div className="flex gap-2"><div className="w-3 h-3 rounded-full bg-rose-500"></div><div className="w-3 h-3 rounded-full bg-amber-500"></div><div className="w-3 h-3 rounded-full bg-emerald-500"></div></div>
                 <button onClick={() => navigator.clipboard.writeText((codeSnippets as any)[activeTab])} className="text-xs font-bold text-indigo-400 hover:text-white transition-all flex items-center gap-2"><Copy size={14}/> COPY CODE</button>
              </div>
              <div className="p-8 overflow-x-auto"><pre className="text-emerald-400 font-mono text-xs leading-relaxed">{(codeSnippets as any)[activeTab]}</pre></div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default BackendPreviewView;