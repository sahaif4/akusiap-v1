import React, { useEffect, useState, useMemo, useRef } from 'react';
import { 
  Radar, RadarChart, PolarGrid, PolarAngleAxis, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, AreaChart, Area, CartesianGrid, XAxis, YAxis, Legend
} from 'recharts';
import { 
  ShieldCheck, TrendingUp, Activity, Loader2, ServerCrash, Building2, List, Clock, BarChart3,
  TrendingDown, Minus, AlertTriangle, Sparkles, ChevronDown, FilePenLine, UploadCloud, Calculator, PlusCircle,
  PieChart as PieChartIcon
} from 'lucide-react';
import { getDashboardData } from '../services/dashboardService';
import { getActivityLog } from '../services/activityLogService';
import { generateDashboardNarrative } from '../services/geminiService';
import { DashboardData, UnitCode, ActivityLogItem } from '../types/dashboard';
import { Role, CurrentUser, StrategicAgenda } from '../types';
import CountdownWidget from '../components/AccreditationCountdown';

const ALL_UNITS: UnitCode[] = ["TMP", "THP", "TAP", "UPPS", "UPPM"];

const KRITERIA_DEFINITIONS: Record<string, string> = {
  "K1": "Visi, Misi, Tujuan, dan Strategi", "K2": "Tata Pamong, Tata Kelola, dan Kerjasama", "K3": "Mahasiswa",
  "K4": "Sumber Daya Manusia", "K5": "Keuangan, Sarana, dan Prasarana", "K6": "Pendidikan",
  "K7": "Penelitian", "K8": "Pengabdian kepada Masyarakat", "K9": "Luaran dan Capaian Tridharma",
};

const DashboardView: React.FC<{ currentUser: CurrentUser | null }> = ({ currentUser }) => {
  const [showAnalytics, setShowAnalytics] = useState(false);
  
  const accessibleUnits = useMemo(() => {
    if (!currentUser) return [];
    const { role, unitCode, assignedUnits } = currentUser;
    if ([Role.SUPER_ADMIN, Role.ADMIN_UPM, Role.PIMPINAN, Role.WADIR].includes(role)) return ALL_UNITS;
    if ([Role.ADMIN_PRODI, Role.KAPRODI, Role.AUDITEE].includes(role)) return unitCode ? [unitCode as UnitCode] : [];
    if (role === Role.AUDITOR) return (assignedUnits as UnitCode[]) || [];
    return [];
  }, [currentUser]);

  const [unit, setUnit] = useState<UnitCode>(accessibleUnits[0] || "TMP");
  const [data, setData] = useState<DashboardData | null>(null);
  const [activityLog, setActivityLog] = useState<ActivityLogItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [narrative, setNarrative] = useState<string | null>(null);
  const [activeAgenda, setActiveAgenda] = useState<StrategicAgenda | null>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!showAnalytics || !currentUser) return;
    setLoading(true);
    const fetchData = async () => {
      try {
        const [dashboardData, logData] = await Promise.all([ getDashboardData(unit, currentUser), getActivityLog() ]);
        setData(dashboardData);
        setActivityLog(logData);
        if (dashboardData) {
          const summary = await generateDashboardNarrative(dashboardData, KRITERIA_DEFINITIONS);
          setNarrative(summary);
        }
      } catch (err: any) {
        setError(err.message || "Gagal memuat data dashboard.");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [unit, currentUser, showAnalytics]);

  const qualityStatus = useMemo(() => {
    if (!data) return { text: '-', color: 'bg-slate-500', textColor: 'text-slate-500' };
    const score = data.stats.average_score;
    if (score >= 3.5) return { text: 'Sangat Baik', color: 'bg-emerald-500', textColor: 'text-emerald-500' };
    if (score >= 3.0) return { text: 'Baik', color: 'bg-blue-500', textColor: 'text-blue-500' };
    return { text: 'Perlu Perbaikan', color: 'bg-amber-500', textColor: 'text-amber-500' };
  }, [data]);

  const { highestCriteria, lowestCriteria } = useMemo(() => {
    if (!data?.radar?.length) return { highestCriteria: { criteria: '-', score: 0 }, lowestCriteria: { criteria: '-', score: 0 } };
    const sorted = [...data.radar].sort((a, b) => b.score - a.score);
    return { highestCriteria: sorted[0], lowestCriteria: sorted[sorted.length - 1] };
  }, [data]);

  if (!showAnalytics) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] text-center space-y-6">
        <div className="p-8 bg-indigo-600 rounded-full text-white shadow-2xl"><BarChart3 size={48} /></div>
        <h2 className="text-3xl font-black text-slate-900">Halo, {currentUser?.name}!</h2>
        <p className="text-slate-500 max-w-md">Dasbor analitik Anda siap memproses data dari seluruh kriteria mutu.</p>
        <button onClick={() => setShowAnalytics(true)} className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl hover:bg-indigo-700 transition-all flex items-center gap-2"><TrendingUp size={18}/> Buka Dasbor Analitik</button>
      </div>
    );
  }

  if (loading) return <div className="flex justify-center items-center h-[60vh]"><Loader2 size={48} className="animate-spin text-indigo-600" /></div>;

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      {/* Header Statis */}
      <div className="bg-slate-900 text-white p-8 rounded-[3rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-[100px] -mr-20 -mt-20"></div>
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8">
           <div className="lg:col-span-4">
              <h2 className="text-3xl font-black tracking-tight">{unit}</h2>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">Siklus AMI 2024/2025</p>
              <div className={`mt-4 flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold border w-fit ${qualityStatus.textColor} bg-white/5 border-white/10`}>
                 <div className={`w-2 h-2 rounded-full ${qualityStatus.color}`}></div>
                 {qualityStatus.text}
              </div>
           </div>
           <div className="lg:col-span-8 bg-white/5 border border-white/10 p-5 rounded-2xl backdrop-blur-sm">
              <div className="flex items-start gap-3">
                 <Sparkles size={18} className="text-indigo-300 mt-1"/>
                 <p className="text-sm text-slate-200 leading-relaxed">{narrative || 'Menganalisis performa mutu...'}</p>
              </div>
           </div>
        </div>
      </div>

      {/* Grid Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
         <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
            <h3 className="font-black text-slate-900 mb-6 flex items-center gap-2"><Activity size={20} className="text-indigo-600"/> Peta Capaian Mutu</h3>
            <div className="h-[400px]">
               <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={data?.radar}>
                    <PolarGrid stroke="#e2e8f0" />
                    <PolarAngleAxis dataKey="criteria" tick={{fill: '#64748b', fontSize: 12, fontWeight: 600}} />
                    <Radar name="Skor" dataKey="score" stroke="#4f46e5" fill="#4f46e5" fillOpacity={0.3} strokeWidth={3} />
                    <Tooltip />
                  </RadarChart>
               </ResponsiveContainer>
            </div>
         </div>
         <div className="space-y-6">
            <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm">
               <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2"><List size={18} className="text-indigo-600"/> Ringkasan Skor</h3>
               <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                     <p className="text-[10px] font-black text-slate-400 uppercase">Rata-rata</p>
                     <p className="text-2xl font-black text-slate-900">{data?.stats.average_score.toFixed(2)}</p>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                     <p className="text-[10px] font-black text-slate-400 uppercase">Temuan</p>
                     <p className="text-2xl font-black text-rose-600">{data?.stats.total_findings}</p>
                  </div>
               </div>
            </div>
            <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm">
               <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2"><Clock size={18} className="text-indigo-600"/> Aktivitas Unit</h3>
               <div className="space-y-4">
                  {activityLog.slice(0, 4).map(log => (
                    <div key={log.id} className="flex items-start gap-3">
                       <div className="w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs font-bold flex-shrink-0">{log.avatar}</div>
                       <div>
                          <p className="text-xs text-slate-700 leading-snug"><span className="font-bold">{log.user}</span> {log.action} <span className="font-bold">{log.target}</span></p>
                          <p className="text-[10px] text-slate-400 mt-0.5">{log.timestamp}</p>
                       </div>
                    </div>
                  ))}
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default DashboardView;