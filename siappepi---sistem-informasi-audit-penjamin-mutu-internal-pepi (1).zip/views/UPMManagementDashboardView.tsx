import React from 'react';
import { Briefcase, User, CheckCircle2, Users, Calendar, Flag, Target, Check, Clock } from 'lucide-react';

const UPM_STRUCTURE = {
  pimpinan: {
    kepala: { nama: 'Irwanto, S.Si., M.Pd.', nip: '198105122009121002', foto: null, desc: 'Bertanggung jawab atas perencanaan, pelaksanaan, dan pengembangan sistem penjaminan mutu secara keseluruhan.' },
    sekretaris: { nama: 'Dwi Rahayu, S.TP., M.Sc.', nip: '199310102022032002', foto: null, desc: 'Membantu Kepala UPM dalam administrasi, dokumentasi, dan pelaporan pelaksanaan sistem manajemen mutu.' }
  },
  tim_kerja: [
    { id: 1, nama_tim: 'Manajemen Mutu & Akreditasi', koordinator: { nama: 'Dr. Mardison S, S.TP., M.Si.' }, anggota: ['Aghniya Ilmahukami', 'Rifari Satrio S.', 'Rivani Yuniar'], tanggung_jawab: 'Melaksanakan fungsi UPM poin 1, 2, 5, dan 7 terkait perencanaan, pengembangan, dan monitoring proses akreditasi.' },
    { id: 2, nama_tim: 'Monitoring dan Evaluasi (Monev)', koordinator: { nama: 'Mas Wisnu Aninditya S.TP., M.Si.' }, anggota: ['Dyah Ayu Shofiati', 'Muhammad Hesa A.G.'], tanggung_jawab: 'Melaksanakan fungsi UPM poin 3 dan 4 terkait pemantauan, evaluasi pelaksanaan, dan pengembangan kerja sama penjaminan mutu.' },
    { id: 3, nama_tim: 'Tempat Uji Kompetensi (TUK)', koordinator: { nama: 'Irwanto, S.Si., M.Pd.' }, anggota: ['Adistya Pramesthi', 'Tikno Agustina'], tanggung_jawab: 'Melaksanakan fungsi UPM poin 6 terkait koordinasi pelaksanaan uji kompetensi dan sertifikasi profesi.' }
  ]
};

const UPM_FUNCTIONS = [
  "Perencanaan, pelaksanaan, dan pengembangan sistem penjamin mutu.",
  "Penyusunan perangkat sistem penjaminan mutu.",
  "Pemantauan dan evaluasi pelaksanaan sistem manajemen mutu.",
  "Pengembangan kerja sama bidang sistem penjamin mutu.",
  "Sosialisasi, pelaksanaan, dan monitoring proses akreditasi dan sertifikasi.",
  "Mengoordinasikan pelaksanaan uji kompetensi dalam rangka sertifikasi profesi.",
  "Penyusunan dan pendokumentasian laporan pelaksanaan sistem manajemen jaminan mutu.",
  "Melaksanakan tugas kedinasan lainnya yang relevan."
];

const MONTHLY_CYCLE = [
    { month: 'Jan', task: 'Perencanaan Mutu & Review Instrumen' }, { month: 'Feb', task: 'Monitoring & Pengumpulan Data Awal' },
    { month: 'Mar', task: 'Pengumpulan & Validasi Data' }, { month: 'Apr', task: 'Evaluasi Internal & Analisis Tren' },
    { month: 'Mei', task: 'Persiapan Audit Mutu Internal (AMI)' }, { month: 'Jun', task: 'Pelaksanaan AMI Semester Genap' },
    { month: 'Jul', task: 'Pelaporan Hasil AMI & Diseminasi' }, { month: 'Agu', task: 'Penyusunan Rencana Tindak Lanjut (RTL)' },
    { month: 'Sep', task: 'Monitoring Pelaksanaan RTL' }, { month: 'Okt', task: 'Rapat Tinjauan Manajemen (RTM) Tengah Tahun' },
    { month: 'Nov', task: 'Evaluasi Akhir Tahun & Persiapan Siklus Baru' }, { month: 'Des', task: 'Pelaporan Kinerja Mutu Tahunan ke Direktur' }
];

const ACCREDITATION_ROADMAP = [
    { timeframe: 'Q1 2025', milestone: 'Konsolidasi Data & Dokumen Pendukung', team: 'Tim Manajemen Mutu', status: 'Selesai' },
    { timeframe: 'Q2 2025', milestone: 'Penyelarasan Instrumen dengan Standar LAM Terbaru', team: 'Tim Manajemen Mutu & Tim Monev', status: 'Berjalan' },
    { timeframe: 'Q3 2025', milestone: 'Penyusunan Draf Laporan Evaluasi Diri (LED)', team: 'Semua Tim & Prodi', status: 'Berjalan' },
    { timeframe: 'Q4 2025', milestone: 'Review Internal & Simulasi Visitasi Akreditasi', team: 'Tim Auditor Internal', status: 'Belum Dimulai' },
    { timeframe: 'Q1 2026', milestone: 'Finalisasi & Pengajuan Borang Akreditasi', team: 'Pimpinan & Kepala UPM', status: 'Belum Dimulai' }
];

const UPMManagementDashboardView: React.FC = () => {
    const currentMonthIndex = new Date().getMonth();
    
    return (
        <div className="space-y-8 animate-in fade-in duration-500 pb-20">
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-10 rounded-[3rem] shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-[100px] -mr-20 -mt-20"></div>
                <div className="relative z-10">
                    <div className="flex items-center gap-4 mb-2">
                        <Briefcase size={28}/>
                        <h2 className="text-3xl font-black tracking-tight">Dasbor Manajemen UPM</h2>
                    </div>
                    <p className="text-slate-400 max-w-2xl">Pusat informasi, panduan operasional, dan panel kontrol strategis untuk Unit Penjaminan Mutu PEPI.</p>
                </div>
            </div>

            <div className="space-y-12">
                {/* Leadership Section */}
                <section>
                    <div className="text-center mb-10">
                        <h3 className="text-2xl font-black text-slate-900">Struktur Kepemimpinan UPM</h3>
                        <p className="text-sm text-slate-500">Berdasarkan SK Direktur tentang Organisasi dan Tata Kelola</p>
                    </div>
                    <div className="flex flex-col items-center gap-6">
                        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-lg w-full max-w-2xl text-center flex flex-col items-center">
                            <div className="w-24 h-24 bg-indigo-100 rounded-full mb-4 flex items-center justify-center border-4 border-white"><User size={48} className="text-indigo-400"/></div>
                            <span className="px-3 py-1 bg-indigo-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest">Ketua UPM</span>
                            <h4 className="text-xl font-bold text-slate-900 mt-3">{UPM_STRUCTURE.pimpinan.kepala.nama}</h4>
                            <p className="text-xs text-slate-400 font-mono">NIP. {UPM_STRUCTURE.pimpinan.kepala.nip}</p>
                            <p className="text-xs text-slate-600 mt-2 max-w-md italic">{UPM_STRUCTURE.pimpinan.kepala.desc}</p>
                        </div>
                        <div className="w-1 h-6 bg-slate-200"></div>
                        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-md w-full max-w-lg text-center flex flex-col items-center">
                             <div className="w-16 h-16 bg-slate-100 rounded-full mb-3 flex items-center justify-center border-4 border-white"><User size={32} className="text-slate-400"/></div>
                            <span className="px-3 py-1 bg-slate-200 text-slate-600 rounded-full text-[9px] font-bold uppercase tracking-wider">Sekretaris UPM</span>
                            <h4 className="text-md font-bold text-slate-800 mt-2">{UPM_STRUCTURE.pimpinan.sekretaris.nama}</h4>
                            <p className="text-xs text-slate-400 font-mono">NIP. {UPM_STRUCTURE.pimpinan.sekretaris.nip}</p>
                        </div>
                    </div>
                </section>

                {/* Function & Responsibility Section */}
                <section>
                     <div className="text-center mb-10">
                        <h3 className="text-2xl font-black text-slate-900">Fungsi dan Tanggung Jawab UPM</h3>
                        <p className="text-sm text-slate-500">Mandat resmi unit sesuai SK Direktur.</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        {UPM_FUNCTIONS.map((func, idx) => (
                            <div key={idx} className="bg-white border border-slate-200 rounded-2xl p-5 flex items-start gap-4 hover:shadow-lg hover:border-indigo-200 transition-all">
                                <CheckCircle2 className="text-emerald-500 mt-1 flex-shrink-0" size={18}/>
                                <p className="text-xs font-semibold text-slate-700">{func}</p>
                            </div>
                        ))}
                    </div>
                </section>
                
                {/* Team Structure */}
                <section>
                    <div className="text-center mb-10"><h3 className="text-2xl font-black text-slate-900">Struktur Tim Kerja & Pembagian Tugas</h3></div>
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        {UPM_STRUCTURE.tim_kerja.map(tim => (
                            <div key={tim.id} className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col">
                                <h4 className="font-black text-indigo-800 text-md uppercase tracking-wider mb-4 pb-4 border-b border-slate-200">{tim.nama_tim}</h4>
                                <div className="space-y-4 flex-1">
                                    <div className="bg-slate-50 p-3 rounded-xl">
                                        <p className="text-[9px] font-bold text-slate-400 uppercase">Koordinator</p>
                                        <p className="text-xs font-bold text-slate-900">{tim.koordinator.nama}</p>
                                    </div>
                                    <div>
                                        <p className="text-[9px] font-bold text-slate-400 uppercase mb-2">Anggota</p>
                                        <ul className="space-y-1">{tim.anggota.map((a, i) => <li key={i} className="text-xs text-slate-600 font-medium list-disc list-inside ml-1">{a}</li>)}</ul>
                                    </div>
                                </div>
                                <div className="mt-6 pt-4 border-t border-slate-200 bg-indigo-50 border-indigo-200 rounded-xl p-3">
                                   <p className="text-[9px] font-black text-indigo-700 uppercase mb-1">Tanggung Jawab Utama</p>
                                   <p className="text-xs text-indigo-900 font-medium">{tim.tanggung_jawab}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>
                
                {/* Monthly Cycle */}
                <section>
                     <div className="text-center mb-10">
                        <h3 className="text-2xl font-black text-slate-900">Siklus Penjaminan Mutu Tahunan</h3>
                        <p className="text-sm text-slate-500">Panduan aktivitas bulanan berbasis siklus PPEPP.</p>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                        {MONTHLY_CYCLE.map((item, idx) => (
                            <div key={idx} className={`p-4 rounded-2xl border-2 transition-all ${idx === currentMonthIndex ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'bg-white border-slate-200 text-slate-700'}`}>
                                <p className={`text-xs font-black ${idx === currentMonthIndex ? 'text-indigo-200' : 'text-slate-400'}`}>{item.month.toUpperCase()}</p>
                                <p className={`text-xs font-bold mt-1 ${idx === currentMonthIndex ? '' : 'text-slate-800'}`}>{item.task}</p>
                            </div>
                        ))}
                    </div>
                </section>

                {/* Accreditation Roadmap */}
                <section>
                    <div className="text-center mb-12">
                        <h3 className="text-2xl font-black text-slate-900">Peta Jalan Persiapan Akreditasi – 2026</h3>
                        <p className="text-sm text-slate-500">Panel kontrol strategis untuk memastikan kesiapan institusi.</p>
                    </div>
                    <div className="relative flex flex-col gap-8 ml-6">
                        <div className="absolute left-6 top-0 bottom-0 w-1 bg-slate-200" />
                        {ACCREDITATION_ROADMAP.map((item, idx) => {
                             const statusStyle = {
                                Selesai: { icon: Check, color: 'emerald' },
                                Berjalan: { icon: Clock, color: 'indigo' },
                                'Belum Dimulai': { icon: Target, color: 'slate' }
                             }[item.status] || { icon: Target, color: 'slate' };
                             const Icon = statusStyle.icon;
                            return (
                            <div key={idx} className="relative z-10 flex items-start gap-8">
                                <div className={`w-12 h-12 rounded-full flex-shrink-0 bg-${statusStyle.color}-600 text-white flex items-center justify-center border-4 border-slate-50 shadow-md`}>
                                    <Flag size={20} />
                                </div>
                                <div className="bg-white p-6 rounded-2xl border border-slate-200 flex-1 shadow-sm">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{item.timeframe}</p>
                                            <h4 className="font-bold text-slate-800">{item.milestone}</h4>
                                            <p className="text-xs text-slate-500 mt-1">Penanggung Jawab: <span className="font-semibold">{item.team}</span></p>
                                        </div>
                                        <div className={`flex items-center gap-2 px-3 py-1 bg-${statusStyle.color}-50 text-${statusStyle.color}-700 rounded-full text-[10px] font-bold border border-${statusStyle.color}-100`}>
                                            <Icon size={12}/>{item.status}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )})}
                    </div>
                </section>

            </div>
        </div>
    );
};

export default UPMManagementDashboardView;