
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Eye, CheckCircle2, XCircle, MessageSquare, FileText, ArrowRight, CornerUpLeft, 
  ClipboardCheck, AlertTriangle, Info, ShieldCheck, Search, Send, RefreshCw, FileWarning, Edit, Users, GitCommitVertical, AlertOctagon, Scale, Save, Link as LinkIcon, Loader2, Lock, ShieldAlert, ClipboardList, ServerCrash, Clock, FileSignature
} from 'lucide-react';
import { DocumentStatus, Instrument, AuditCycle, AuditCycleStatus, AuditorEvaluation, CurrentUser, Role, UnitSubmissionStatus, User } from '../types';
import * as apiService from '../services/apiService';

const SCORE_CONFLICT_THRESHOLD = 0.25;

// --- SUB-COMPONENTS ---
const DeskEvalHeader: React.FC<{ cycle: AuditCycle | null, unitName: string, submissionStatus: UnitSubmissionStatus | null }> = ({ cycle, unitName, submissionStatus }) => {
    if (!cycle) return null;

    const deadline = new Date();
    deadline.setDate(deadline.getDate() + 5);
    const daysRemaining = 5;
    const deadlineColor = daysRemaining > 3 ? 'text-emerald-600 bg-emerald-50 border-emerald-200' : 'text-amber-600 bg-amber-50 border-amber-200';
    
    const getStatusChip = (status: UnitSubmissionStatus | null) => {
        if (!status) return { text: 'Memuat...', color: 'bg-slate-100 text-slate-600' };
        switch(status) {
          case UnitSubmissionStatus.DRAFT: return { text: 'Draft', color: 'bg-slate-100 text-slate-600' };
          case UnitSubmissionStatus.SUBMITTED: return { text: 'Terkirim', color: 'bg-emerald-100 text-emerald-700' };
          case UnitSubmissionStatus.RETURNED: return { text: 'Dikembalikan', color: 'bg-amber-100 text-amber-700' };
          default: return { text: status, color: 'bg-blue-100 text-blue-700' };
        }
    };
    const statusChip = getStatusChip(submissionStatus);


    return (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm mb-6 flex flex-col md:flex-row justify-between items-start gap-4">
            <div>
                <h3 className="font-bold text-sm uppercase text-slate-500 tracking-wider">Workspace Desk Evaluation</h3>
                <div className="flex items-center gap-3">
                    <p className="text-2xl font-black text-slate-900">{unitName}</p>
                    <span className={`px-2 py-1 rounded-full text-[9px] font-bold border ${statusChip.color}`}>{statusChip.text}</span>
                </div>
                <span className="text-xs font-bold text-slate-400">Auditee menyerahkan berkas 2 jam yang lalu.</span>
            </div>
            <div className={`p-4 rounded-xl border ${deadlineColor} text-center`}>
                <p className="text-[10px] font-black uppercase tracking-widest">Sisa Waktu Evaluasi</p>
                <p className="text-2xl font-black">{daysRemaining} Hari</p>
            </div>
        </div>
    );
};


const FinalizationPanel: React.FC<{
    onFinalize: () => void;
    checks: { allEvaluated: boolean; noConflicts: boolean };
    isFinalized: boolean;
}> = ({ onFinalize, checks, isFinalized }) => {
    
    const canFinalize = checks.allEvaluated && checks.noConflicts;

    if (isFinalized) {
        return (
            <div className="p-6 rounded-3xl bg-emerald-50 border-emerald-200 text-center">
                <CheckCircle2 size={32} className="mx-auto text-emerald-600 mb-2"/>
                <h3 className="font-bold text-emerald-800">Desk Evaluation Selesai & Terkunci</h3>
                <p className="text-xs text-emerald-600 mt-1">Siklus audit dapat dilanjutkan ke tahap Audit Lapangan.</p>
            </div>
        );
    }
    
    return (
        <div className="p-6 rounded-3xl bg-indigo-50 border-2 border-dashed border-indigo-200">
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div>
                    <h3 className="text-lg font-black text-indigo-900 flex items-center gap-2"><ShieldAlert size={20}/> Tanda Tangan & Finalisasi</h3>
                    <p className="text-xs text-indigo-700 mt-1">Setelah semua penilaian final dan konflik terselesaikan, dokumen dapat ditandatangani.</p>
                </div>
                <button onClick={onFinalize} disabled={!canFinalize} className="px-6 py-3 bg-indigo-600 text-white rounded-2xl text-sm font-bold shadow-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all">
                    <FileSignature size={18}/> Kunci & Minta TTD
                </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-indigo-100">
                <div className={`flex items-start gap-3 p-3 rounded-xl ${checks.allEvaluated ? 'bg-emerald-50' : 'bg-slate-50'}`}>
                    {checks.allEvaluated ? <CheckCircle2 className="text-emerald-500 mt-0.5"/> : <XCircle className="text-rose-400 mt-0.5"/>}
                    <p className="text-xs font-bold">{checks.allEvaluated ? 'Semua instrumen telah dievaluasi oleh kedua auditor.' : 'Beberapa instrumen belum selesai dievaluasi.'}</p>
                </div>
                <div className={`flex items-start gap-3 p-3 rounded-xl ${checks.noConflicts ? 'bg-emerald-50' : 'bg-amber-50'}`}>
                    {checks.noConflicts ? <CheckCircle2 className="text-emerald-500 mt-0.5"/> : <AlertTriangle className="text-amber-500 mt-0.5"/>}
                    <p className="text-xs font-bold">{checks.noConflicts ? 'Tidak ada konflik skor yang signifikan.' : 'Masih terdapat konflik skor yang perlu didiskusikan.'}</p>
                </div>
            </div>
        </div>
    );
};

const StatusPlaceholder: React.FC<{ status: UnitSubmissionStatus, onRefresh: () => void }> = ({ status, onRefresh }) => {
    const config = {
      [UnitSubmissionStatus.DRAFT]: { icon: <Clock size={40}/>, title: 'Menunggu Berkas dari Auditee', message: "Auditor dapat memulai evaluasi setelah auditee mengirimkan semua dokumen bukti." },
      [UnitSubmissionStatus.READY_TO_SUBMIT]: { icon: <Clock size={40}/>, title: 'Menunggu Berkas dari Auditee', message: "Auditee sedang bersiap mengirimkan berkas. Mohon tunggu sebentar." },
      [UnitSubmissionStatus.RETURNED]: { icon: <RefreshCw size={40}/>, title: 'Berkas Dikembalikan ke Auditee', message: "Dokumen telah dikembalikan untuk revisi. Workspace akan terbuka kembali setelah Auditee mengirim ulang." }
    };
    const current = config[status] || config[UnitSubmissionStatus.DRAFT];

    return (
        <div className="text-center py-20 bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center text-slate-400 mb-6 shadow-inner border">
                {current.icon}
            </div>
            <h3 className="font-black text-xl text-slate-700">{current.title}</h3>
            <p className="text-sm text-slate-500 max-w-sm mx-auto mt-2">{current.message}</p>
            <button onClick={onRefresh} className="mt-6 px-4 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold flex items-center gap-2">
                <RefreshCw size={14}/> Refresh Status
            </button>
        </div>
    );
};


// --- MAIN COMPONENT ---
interface DeskEvaluationViewProps {
  currentUser: CurrentUser | null;
}

const DeskEvaluationView: React.FC<DeskEvaluationViewProps> = ({ currentUser }) => {
  const [instruments, setInstruments] = useState<Instrument[]>([]);
  const [auditCycles, setAuditCycles] = useState<Record<string, AuditCycle>>({});
  const [selectedUnit, setSelectedUnit] = useState<string | null>(null);
  const [activeInstrumentId, setActiveInstrumentId] = useState<number|null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submissionStatus, setSubmissionStatus] = useState<UnitSubmissionStatus | null>(null);
  const [allAuditors, setAllAuditors] = useState<User[]>([]);

  useEffect(() => {
    const fetchAuditors = async () => {
      try {
        const users = await apiService.getUsers();
        setAllAuditors(users.filter(u => u.role === Role.AUDITOR));
      } catch (e) {
        console.error("Gagal memuat data auditor", e);
      }
    };
    fetchAuditors();
  }, []);

  const fetchDataForUnit = async (unitName: string) => {
    if (!currentUser) return;
    setIsLoading(true); setError(null);
    try {
      const [instrumentsData, statusData] = await Promise.all([
        apiService.getDeskEvaluationInstruments(unitName),
        apiService.getSubmissionStatus(unitName)
      ]);

      setInstruments(instrumentsData);
      setSubmissionStatus(statusData);
    } catch (error: any) {
      setError(error.message || "Gagal memuat data instrumen.");
    } finally {
      setIsLoading(false);
    }
  };
  
  useEffect(() => {
    const cyclesRaw = localStorage.getItem('siapepi_audit_cycles');
    const loadedCycles = cyclesRaw ? JSON.parse(cyclesRaw) : {};
    if (!loadedCycles['Prodi Teknologi Mekanisasi Pertanian']) {
        loadedCycles['Prodi Teknologi Mekanisasi Pertanian'] = { unit: 'Prodi Teknologi Mekanisasi Pertanian', status: AuditCycleStatus.DESK_EVALUATION_IN_PROGRESS };
    }
    setAuditCycles(loadedCycles);
  }, []);

  useEffect(() => {
    if (selectedUnit) {
      fetchDataForUnit(selectedUnit);
    } else {
      setInstruments([]);
      setSubmissionStatus(null);
    }
  }, [selectedUnit, currentUser]);
  
  const auditUnits = useMemo(() => Object.keys(auditCycles).filter(unitName => auditCycles[unitName].status === AuditCycleStatus.DESK_EVALUATION_IN_PROGRESS), [auditCycles]);
  const activeCycle = useMemo(() => selectedUnit ? auditCycles[selectedUnit] : null, [selectedUnit, auditCycles]);
  const isFinalized = activeCycle?.status !== AuditCycleStatus.DESK_EVALUATION_IN_PROGRESS;
  const showWorkspace = submissionStatus === UnitSubmissionStatus.SUBMITTED || submissionStatus === UnitSubmissionStatus.ACCEPTED;

  const validationChecks = useMemo(() => {
    if (!currentUser || instruments.length === 0) return { allEvaluated: false, noConflicts: false };
    const allEvaluated = instruments.every(i => {
      const peerId = i.auditor_ids?.find(id => id !== currentUser.id);
      return i.evaluations?.[String(currentUser.id)]?.isComplete && (peerId ? i.evaluations?.[String(peerId)]?.isComplete : false);
    });
    const noConflicts = instruments.every(i => !i.conflict);
    return { allEvaluated, noConflicts };
  }, [instruments, currentUser]);


  const handleEvaluationChange = (instrumentId: number, field: keyof AuditorEvaluation, value: any) => {
    if(isFinalized || !currentUser) return;
    setInstruments(prev => prev.map(inst => {
      if (inst.id === instrumentId) {
        const myEval = inst.evaluations?.[String(currentUser.id)] || { status: DocumentStatus.MISSING, isComplete: false };
        const updatedEval = { ...myEval, [field]: value };
        return { ...inst, evaluations: { ...inst.evaluations, [String(currentUser.id)]: updatedEval } };
      }
      return inst;
    }));
  };
  
  const handleSaveDraft = async (instrumentId: number) => {
    if (!currentUser) return;
    const inst = instruments.find(i => i.id === instrumentId);
    if (!inst || !inst.audit_response_id) return;

    const myEval = inst.evaluations?.[String(currentUser.id)];
    if (!myEval) return;

    try {
        await apiService.submitDeskScore({
            audit_response_id: inst.audit_response_id,
            auditor_id: currentUser.id,
            score: myEval.skor_desk,
            note: myEval.catatan_desk,
            status: myEval.status,
            doc_note: myEval.doc_note,
            isComplete: false,
        });
        alert(`Draf untuk instrumen ID ${instrumentId} berhasil disimpan.`);
    } catch (e: any) {
        alert(`Gagal menyimpan draf: ${e.message}`);
    }
  };
  
  const handleFinalizeEvaluation = async (instrumentId: number) => {
    if (!currentUser) return;
    const inst = instruments.find(i => i.id === instrumentId);
    if (!inst || !inst.audit_response_id) return;

    const myEval = inst.evaluations?.[String(currentUser.id)];
    if (!myEval) return;
    if (myEval.status === DocumentStatus.REJECTED && !myEval.doc_note?.trim()) {
      return alert('Alasan penolakan wajib diisi jika status "Perlu Revisi".');
    }

    if (!window.confirm("Anda yakin ingin memfinalisasi penilaian ini? Anda tidak akan dapat mengubahnya lagi.")) return;
    
    try {
       await apiService.submitDeskScore({
            audit_response_id: inst.audit_response_id,
            auditor_id: currentUser.id,
            score: myEval.skor_desk,
            note: myEval.catatan_desk,
            status: myEval.status,
            doc_note: myEval.doc_note,
            isComplete: true,
        });

        // Update local state to reflect finalization
        setInstruments(prev => prev.map(i => i.id === instrumentId ? { ...i, evaluations: { ...i.evaluations, [String(currentUser.id)]: { ...myEval, isComplete: true } } } : i));
    } catch(e: any) {
       alert(`Gagal finalisasi: ${e.message}`);
    }
  };

  if (!currentUser) {
    return <div className="text-center py-10"><Loader2 size={24} className="animate-spin text-indigo-500"/> Memuat data pengguna...</div>;
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <h2 className="text-3xl font-black text-slate-900 tracking-tight">Desk Evaluation (Audit Kecukupan)</h2>
      {!selectedUnit ? (
        auditUnits.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {auditUnits.map(unit => (
              <button key={unit} onClick={() => setSelectedUnit(unit)} className="bg-white border border-slate-200 p-6 rounded-[2rem] text-left hover:border-indigo-300 hover:shadow-xl transition-all group relative overflow-hidden">
                  <h3 className="text-lg font-black text-slate-900">{unit}</h3>
              </button>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-slate-50 border-2 border-dashed border-slate-200 rounded-[3rem]"><h3 className="font-black text-xl text-slate-700">Tidak Ada Audit Aktif</h3></div>
        )
      ) : (
        <div className="space-y-6 animate-in slide-in-from-right-8 duration-500">
           <div className="flex items-center justify-between"><button onClick={() => setSelectedUnit(null)} className="flex items-center gap-2 text-xs font-bold"><CornerUpLeft size={16}/> Kembali</button></div>
           
           <DeskEvalHeader cycle={activeCycle} unitName={selectedUnit} submissionStatus={submissionStatus} />
           
           {isLoading ? <div className="text-center py-10"><Loader2 size={24} className="animate-spin text-indigo-500"/></div> :
           error ? <div className="flex flex-col items-center justify-center h-full min-h-[20vh] bg-rose-50 border border-rose-200 rounded-2xl p-8"><ServerCrash size={32} className="text-rose-400" /><h3 className="mt-2 text-md font-bold text-rose-800">{error}</h3></div> :
           !showWorkspace ? <StatusPlaceholder status={submissionStatus!} onRefresh={() => fetchDataForUnit(selectedUnit)} /> :
           (
            <>
              <FinalizationPanel checks={validationChecks} onFinalize={() => {}} isFinalized={isFinalized}/>
              {instruments.map(inst => {
                  const myEval = inst.evaluations?.[String(currentUser.id)];
                  const peerAuditorId = inst.auditor_ids?.find(id => id !== currentUser.id);
                  const peerAuditor = allAuditors.find(a => a.id === peerAuditorId);
                  const peerEval = peerAuditorId ? inst.evaluations?.[String(peerAuditorId)] : undefined;
                  
                  if (!myEval || !peerEval || !peerAuditor) return null;
                  
                  const isMyEvalFinal = myEval.isComplete;

                  return (
                    <div key={inst.id} className={`p-6 bg-white border-2 rounded-3xl transition-all ${activeInstrumentId === inst.id ? 'border-indigo-400 shadow-xl' : 'border-slate-200'}`}>
                        <div onClick={() => setActiveInstrumentId(inst.id === activeInstrumentId ? null : inst.id)} className="flex justify-between items-start gap-4 cursor-pointer">
                            <p className="font-bold text-slate-800 flex-1 pr-8 leading-relaxed">{inst.pertanyaan}</p>
                        </div>

                        {activeInstrumentId === inst.id && (
                            <div className="mt-6 pt-6 border-t border-slate-200 animate-in fade-in duration-300 space-y-6">
                                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200"><h4 className="text-[10px] font-black uppercase text-slate-500 tracking-wider">Data dari Auditee</h4> {inst.doc_file && <a href="#" className="text-xs font-bold text-indigo-600 flex items-center gap-2 underline"><LinkIcon size={14}/> {inst.doc_file}</a>}</div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="bg-white p-4 rounded-2xl border-2 border-indigo-200 shadow-lg">
                                        <h4 className="font-bold text-xs uppercase text-indigo-600 mb-3">Evaluasi Anda</h4>
                                        <textarea className="w-full p-3 border rounded-lg text-sm h-24" placeholder="Catatan Anda..." value={myEval.catatan_desk || ''} onChange={(e) => handleEvaluationChange(inst.id, 'catatan_desk', e.target.value)} disabled={isMyEvalFinal}/>
                                        <div className="flex gap-2 mt-2">
                                          <select className="flex-1 p-2 border rounded-lg text-sm font-bold" value={myEval.skor_desk ?? ''} onChange={(e) => handleEvaluationChange(inst.id, 'skor_desk', e.target.value === '' ? undefined : parseInt(e.target.value))} disabled={isMyEvalFinal}>
                                                <option value="">Skor</option>{[0,1,2,3,4].map(s => <option key={s} value={s}>{s}</option>)}
                                          </select>
                                          <button onClick={() => handleEvaluationChange(inst.id, 'status', DocumentStatus.APPROVED)} className={`p-2 rounded-lg text-xs font-bold flex-1 ${myEval.status === DocumentStatus.APPROVED ? 'bg-emerald-600 text-white' : 'bg-white border'}`} disabled={isMyEvalFinal}>Valid</button>
                                          <button onClick={() => handleEvaluationChange(inst.id, 'status', DocumentStatus.REJECTED)} className={`p-2 rounded-lg text-xs font-bold flex-1 ${myEval.status === DocumentStatus.REJECTED ? 'bg-rose-600 text-white' : 'bg-white border'}`} disabled={isMyEvalFinal}>Revisi</button>
                                        </div>
                                        {myEval.status === DocumentStatus.REJECTED && <input type="text" value={myEval.doc_note || ''} onChange={(e) => handleEvaluationChange(inst.id, 'doc_note', e.target.value)} placeholder="Alasan Penolakan..." className="w-full mt-2 p-2 border-rose-300 bg-rose-50 text-rose-800 rounded-lg text-xs" disabled={isMyEvalFinal}/>}
                                        {!isMyEvalFinal && (
                                            <div className="flex gap-2 mt-4">
                                                <button onClick={() => handleSaveDraft(inst.id)} className="flex-1 px-3 py-2 text-xs font-bold bg-slate-100 text-slate-600 rounded-lg">Simpan Draf</button>
                                                <button onClick={() => handleFinalizeEvaluation(inst.id)} className="flex-1 px-3 py-2 text-xs font-bold bg-indigo-600 text-white rounded-lg shadow-md">Finalisasi</button>
                                            </div>
                                        )}
                                    </div>
                                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                                        <h4 className="font-bold text-xs uppercase text-teal-600 mb-3">Evaluasi {peerAuditor.nama.split(',')[0]}</h4>
                                        {peerEval.isComplete ? (
                                            <>
                                                <p className="text-xs p-3 bg-white rounded-lg h-24 overflow-y-auto border">{peerEval.catatan_desk || <span className="italic text-slate-400">Tidak ada catatan.</span>}</p>
                                                <div className="mt-2 text-center text-xs font-bold p-2 bg-white rounded-lg border flex justify-between items-center"><span>Status: {peerEval.status}</span><span className="text-2xl font-black">{peerEval.skor_desk ?? '-'}</span></div>
                                            </>
                                        ) : <div className="text-center pt-10 text-xs italic text-slate-400">Menunggu penilaian dari rekan auditor.</div> }
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                  )
              })}
            </>
           )}
        </div>
      )}
    </div>
  );
};

export default DeskEvaluationView;
