
import React, { useState, useEffect } from 'react';
import { Settings, Users, FileText, CheckCircle, Clock, PlayCircle, BarChart2, Plus, Trash2, Edit, Save, X, Target, Database, BookOpen, ChevronDown } from 'lucide-react';
import { Standard, User, Unit, Role } from '../types';
import * as apiService from '../services/apiService';

const AUDIT_CYCLES_DATA = [
  { id: 1, name: 'AMI Semester Ganjil 2024/2025', status: 'Aktif', progress: 45, startDate: '2024-09-01', endDate: '2025-01-31' },
  { id: 2, name: 'AMI Semester Genap 2023/2024', status: 'Selesai', progress: 100, startDate: '2024-02-01', endDate: '2024-06-30' },
  { id: 3, name: 'AMI Susulan Laboratorium', status: 'Perencanaan', progress: 10, startDate: '2024-11-01', endDate: '2024-11-30' },
];

const AUDITORS_DATA = [
  { id: 10, name: 'Irwanto, S.Si., M.Pd.', activeAssignments: 3 },
  { id: 12, name: 'Dr. Mardison S, S.TP., M.Si.', activeAssignments: 3 },
  { id: 3, name: 'Mas Wisnu Aninditya S.TP., M.Si.', activeAssignments: 2 },
];

const STANDARD_DOCUMENTS_DATA = [
  { id: 1, name: 'Standar Pendidikan PEPI 2024', version: 'v3.1', date: '2024-08-15' },
  { id: 2, name: 'Standar Penelitian PEPI 2024', version: 'v2.5', date: '2024-08-15' },
  { id: 3, name: 'Permendiktisaintek No. 39 Tahun 2025', version: 'Nasional', date: '2025-01-01' },
];

// --- MODAL COMPONENTS (Inline) ---

const CreateCycleModal = ({ onClose, onSave }: { onClose: () => void, onSave: (cycle: any) => void }) => {
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        const newCycle = {
            id: Date.now(),
            name: formData.get('name') as string,
            startDate: formData.get('startDate') as string,
            endDate: formData.get('endDate') as string,
            status: 'Perencanaan',
            progress: 0,
        };
        onSave(newCycle);
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
            <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 w-full max-w-md space-y-4">
                <h3 className="font-bold">Buat Siklus Audit Baru</h3>
                <div><label className="text-xs">Nama Siklus</label><input name="name" required className="w-full border p-2 rounded-lg mt-1"/></div>
                <div className="grid grid-cols-2 gap-4">
                    <div><label className="text-xs">Tanggal Mulai</label><input name="startDate" type="date" required className="w-full border p-2 rounded-lg mt-1"/></div>
                    <div><label className="text-xs">Tanggal Selesai</label><input name="endDate" type="date" required className="w-full border p-2 rounded-lg mt-1"/></div>
                </div>
                <div className="flex gap-2 justify-end"><button type="button" onClick={onClose} className="px-4 py-2 bg-slate-100 rounded-lg text-sm">Batal</button><button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm">Simpan</button></div>
            </form>
        </div>
    );
};

const AssignAuditorModal = ({ onClose, onSave, allCycles, allUnits, allAuditors }: { onClose: any, onSave: any, allCycles: any[], allUnits: Unit[], allAuditors: User[] }) => {
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
            <div className="bg-white rounded-2xl p-6 w-full max-w-lg space-y-4">
                <h3 className="font-bold">Penugasan Auditor</h3>
                <div><label className="text-xs">Siklus Audit</label><select className="w-full border p-2 rounded-lg mt-1">{allCycles.map(c => <option key={c.id}>{c.name}</option>)}</select></div>
                <div><label className="text-xs">Unit Kerja</label><select className="w-full border p-2 rounded-lg mt-1">{allUnits.map(u => <option key={u.id}>{u.nama_unit}</option>)}</select></div>
                <div><label className="text-xs">Auditor 1</label><select className="w-full border p-2 rounded-lg mt-1">{allAuditors.map(a => <option key={a.id}>{a.nama}</option>)}</select></div>
                <div><label className="text-xs">Auditor 2</label><select className="w-full border p-2 rounded-lg mt-1">{allAuditors.map(a => <option key={a.id}>{a.nama}</option>)}</select></div>
                <div className="flex gap-2 justify-end"><button onClick={onClose} className="px-4 py-2 bg-slate-100 rounded-lg text-sm">Batal</button><button onClick={onSave} className="px-4 py-2 bg-rose-600 text-white rounded-lg text-sm">Tugaskan</button></div>
            </div>
        </div>
    );
};

const AddStandardDocModal = ({ onClose, onSave }: { onClose: () => void, onSave: (doc: any) => void }) => {
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        const newDoc = {
            id: Date.now(),
            name: formData.get('name') as string,
            version: formData.get('version') as string,
            date: formData.get('date') as string,
        };
        onSave(newDoc);
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
            <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 w-full max-w-md space-y-4">
                <h3 className="font-bold">Tambah Dokumen Standar</h3>
                <div><label className="text-xs">Nama Dokumen</label><input name="name" required className="w-full border p-2 rounded-lg mt-1"/></div>
                <div className="grid grid-cols-2 gap-4">
                    <div><label className="text-xs">Versi</label><input name="version" required className="w-full border p-2 rounded-lg mt-1"/></div>
                    <div><label className="text-xs">Tanggal</label><input name="date" type="date" required className="w-full border p-2 rounded-lg mt-1"/></div>
                </div>
                <div className="flex gap-2 justify-end"><button type="button" onClick={onClose} className="px-4 py-2 bg-slate-100 rounded-lg text-sm">Batal</button><button type="submit" className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm">Tambah</button></div>
            </form>
        </div>
    );
};


const InstrumentBankManager: React.FC = () => {
    const [bankType, setBankType] = useState<'standar' | 'unggul'>('standar');
    const [standards, setStandards] = useState<Standard[]>([]);
    const [bank, setBank] = useState<Record<string, any[]>>({});
    const [selectedStandard, setSelectedStandard] = useState<string>('');
    const [newQuestion, setNewQuestion] = useState({ q: '', proof: '' });
    const [editingItemId, setEditingItemId] = useState<number | null>(null);
    const [editForm, setEditForm] = useState({ q: '', proof: '' });

    useEffect(() => {
        const fetchData = async () => {
            const [stds, bn_] = await Promise.all([apiService.getStandards(bankType), apiService.getInstrumentBank(bankType)]);
            setStandards(stds);
            setBank(bn_);
            if (stds.length > 0) {
                setSelectedStandard(stds[0].kode_standar);
            } else {
                setSelectedStandard('');
            }
        };
        fetchData();
    }, [bankType]);

    const handleSaveBank = async (updatedBank: Record<string, any[]>) => {
        setBank(updatedBank);
        await apiService.saveInstrumentBank(updatedBank, bankType);
    };

    const handleAdd = () => {
        if (!newQuestion.q.trim() || !newQuestion.proof.trim()) return;
        const updatedBank = { ...bank };
        if (!updatedBank[selectedStandard]) updatedBank[selectedStandard] = [];
        updatedBank[selectedStandard].push({ id: Date.now(), ...newQuestion });
        handleSaveBank(updatedBank);
        setNewQuestion({ q: '', proof: '' });
    };

    const handleDelete = (id: number) => {
        if (!confirm('Hapus pertanyaan ini dari bank data?')) return;
        const updatedBank = { ...bank };
        updatedBank[selectedStandard] = updatedBank[selectedStandard].filter(item => item.id !== id);
        handleSaveBank(updatedBank);
    };
    
    const handleEditClick = (item: { id: number; q: string; proof: string }) => {
        setEditingItemId(item.id);
        setEditForm({ q: item.q, proof: item.proof });
    };

    const handleCancelEdit = () => {
        setEditingItemId(null);
    };

    const handleUpdate = () => {
        if (!editingItemId) return;
        const updatedBank = { ...bank };
        updatedBank[selectedStandard] = updatedBank[selectedStandard].map(item =>
            item.id === editingItemId ? { ...item, ...editForm } : item
        );
        handleSaveBank(updatedBank);
        setEditingItemId(null);
    };

    return (
        <div className="bg-white border border-slate-200 rounded-[2.5rem] p-8 shadow-sm">
            <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2 mb-4"><Database size={20} className="text-blue-600" /> Bank Data Instrumen AMI</h3>
            
            <div className="mb-4">
                <label className="text-xs font-bold text-slate-500">Pilih Set Standar</label>
                <div className="flex gap-2 mt-1 p-1 bg-slate-100 rounded-xl">
                    <button onClick={() => setBankType('standar')} className={`flex-1 p-2 rounded-lg text-xs font-bold ${bankType==='standar' ? 'bg-white shadow' : ''}`}>Standar PEPI</button>
                    <button onClick={() => setBankType('unggul')} className={`flex-1 p-2 rounded-lg text-xs font-bold ${bankType==='unggul' ? 'bg-white shadow' : ''}`}>Standar Unggul 2025</button>
                </div>
            </div>

            <div>
                <label className="text-sm font-medium text-slate-700">Pilih Standar</label>
                <div className="relative mt-1">
                    <select value={selectedStandard} onChange={e => setSelectedStandard(e.target.value)} className="w-full border border-slate-300 p-3 rounded-xl text-sm appearance-none font-medium">
                        {standards.map(s => <option key={s.id} value={s.kode_standar}>{s.kode_standar}: {s.nama_standar}</option>)}
                    </select>
                    <ChevronDown size={20} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"/>
                </div>
            </div>
            <div className="space-y-3 mt-6 max-h-[28rem] overflow-y-auto pr-2 -mr-2 custom-scrollbar">
                {(bank[selectedStandard] || []).map(item => (
                    <div key={item.id} className="bg-slate-50 p-4 rounded-xl border border-slate-200 group">
                       {editingItemId === item.id ? (
                           <div className="space-y-2 animate-in fade-in duration-300">
                               <textarea value={editForm.q} onChange={(e) => setEditForm({...editForm, q: e.target.value})} className="w-full border p-2 rounded-lg text-sm" rows={3}/>
                               <input value={editForm.proof} onChange={(e) => setEditForm({...editForm, proof: e.target.value})} className="w-full border p-2 rounded-lg text-xs" placeholder="Bukti wajib..."/>
                               <div className="flex gap-2 mt-2">
                                   <button onClick={handleUpdate} className="px-3 py-1 bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1"><Save size={12}/> Simpan</button>
                                   <button onClick={handleCancelEdit} className="text-xs font-bold text-slate-500">Batal</button>
                               </div>
                           </div>
                       ) : (
                           <div>
                               <p className="text-sm font-bold text-slate-800">{item.q}</p>
                               <p className="text-xs text-slate-500 italic mt-2">Bukti: {item.proof}</p>
                               <div className="flex gap-4 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                                   <button onClick={() => handleEditClick(item)} className="text-indigo-600 text-xs font-bold flex items-center gap-1"><Edit size={12}/> Edit</button>
                                   <button onClick={() => handleDelete(item.id)} className="text-rose-500 text-xs font-bold flex items-center gap-1"><Trash2 size={12}/> Hapus</button>
                               </div>
                           </div>
                       )}
                    </div>
                ))}
            </div>
            <div className="mt-6 pt-6 border-t space-y-3">
                <h4 className="text-sm font-medium text-slate-700">Tambah Pertanyaan Baru ke {selectedStandard}:</h4>
                <textarea value={newQuestion.q} onChange={e => setNewQuestion({...newQuestion, q: e.target.value})} placeholder="Teks pertanyaan..." className="w-full border p-3 rounded-xl text-sm" rows={3}/>
                <input value={newQuestion.proof} onChange={e => setNewQuestion({...newQuestion, proof: e.target.value})} placeholder="Bukti wajib..." className="w-full border p-3 rounded-xl text-sm"/>
                <button onClick={handleAdd} className="px-6 py-3 bg-blue-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-blue-100">Tambah</button>
            </div>
        </div>
    );
};


const UPMAdminView: React.FC = () => {
    const [cycles, setCycles] = useState(AUDIT_CYCLES_DATA);
    const [documents, setDocuments] = useState(STANDARD_DOCUMENTS_DATA);
    const [allUnits, setAllUnits] = useState<Unit[]>([]);
    const [allAuditors, setAllAuditors] = useState<User[]>([]);

    const [isCycleModalOpen, setIsCycleModalOpen] = useState(false);
    const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
    const [isDocModalOpen, setIsDocModalOpen] = useState(false);

    useEffect(() => {
        const fetchMasterData = async () => {
            const units = await apiService.getUnits();
            const users = await apiService.getUsers();
            setAllUnits(units);
            setAllAuditors(users.filter(u => u.role === Role.AUDITOR));
        };
        fetchMasterData();
    }, []);

    const handleCreateCycle = (newCycle: any) => {
        setCycles(prev => [newCycle, ...prev]);
        setIsCycleModalOpen(false);
    };

    const handleAssignAuditor = () => {
        alert("Penugasan auditor berhasil disimpan (simulasi).");
        setIsAssignModalOpen(false);
    };
    
    const handleAddDocument = (newDoc: any) => {
        setDocuments(prev => [newDoc, ...prev]);
        setIsDocModalOpen(false);
    };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Workspace Admin UPM</h2>
          <p className="text-sm text-slate-500 font-medium">Panel kontrol untuk manajemen siklus, auditor, dan dokumen standar.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white border border-slate-200 rounded-[2.5rem] p-8 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2"><Settings size={20} className="text-indigo-600"/> Manajemen Siklus Audit</h3>
              <button onClick={() => setIsCycleModalOpen(true)} className="px-5 py-2.5 bg-indigo-600 text-white rounded-full text-xs font-bold shadow-lg flex items-center gap-2"><Plus size={14}/> Buat Siklus Baru</button>
            </div>
            <div className="space-y-4">
              {cycles.map(cycle => (
                <div key={cycle.id} className="bg-slate-50 border border-slate-100 p-4 rounded-2xl">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {cycle.status === 'Aktif' && <PlayCircle size={14} className="text-emerald-500"/>}
                        {cycle.status === 'Selesai' && <CheckCircle size={14} className="text-slate-400"/>}
                        {cycle.status === 'Perencanaan' && <Clock size={14} className="text-amber-500"/>}
                        <h4 className="font-bold text-slate-800 text-sm">{cycle.name}</h4>
                      </div>
                      <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                        <div className="h-full bg-indigo-500" style={{width: `${cycle.progress}%`}} />
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-2xl font-black text-indigo-700">{cycle.progress}%</p>
                      <p className="text-[10px] font-bold text-slate-400">{new Date(cycle.startDate).toLocaleDateString()} - {new Date(cycle.endDate).toLocaleDateString()}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <InstrumentBankManager />

          <div className="bg-white border border-slate-200 rounded-[2.5rem] p-8 shadow-sm">
             <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2"><FileText size={20} className="text-emerald-600"/> Dokumen Standar Mutu</h3>
                <button onClick={() => setIsDocModalOpen(true)} className="px-5 py-2.5 bg-emerald-600 text-white rounded-full text-xs font-bold shadow-lg flex items-center gap-2"><Plus size={14}/> Tambah Dokumen</button>
             </div>
             <table className="w-full text-left text-xs">
                <thead><tr className="border-b"><th className="p-2">Nama Dokumen</th><th className="p-2">Versi</th><th className="p-2">Tanggal</th></tr></thead>
                <tbody>
                  {documents.map(doc => (
                    <tr key={doc.id} className="border-b last:border-none">
                      <td className="p-3 font-bold">{doc.name}</td>
                      <td className="p-3"><span className="px-2 py-0.5 bg-slate-100 rounded text-slate-600 font-bold">{doc.version}</span></td>
                      <td className="p-3 text-slate-500">{doc.date}</td>
                    </tr>
                  ))}
                </tbody>
             </table>
          </div>
        </div>

        <div className="space-y-6 lg:sticky lg:top-8">
          <div className="bg-white border border-slate-200 rounded-[2.5rem] p-8 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2"><Users size={20} className="text-rose-600"/> Tim Auditor</h3>
              <button onClick={() => setIsAssignModalOpen(true)} className="px-5 py-2.5 bg-rose-600 text-white rounded-full text-xs font-bold shadow-lg flex items-center gap-2"><Plus size={14}/> Tugaskan</button>
            </div>
            <div className="space-y-4">
              {AUDITORS_DATA.map(auditor => (
                <div key={auditor.id} className="flex items-center gap-4 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                   <div className="w-10 h-10 rounded-full bg-slate-200 text-slate-500 flex items-center justify-center font-bold">{auditor.name.charAt(0)}</div>
                   <div>
                      <p className="font-bold text-slate-800 text-sm">{auditor.name}</p>
                      <p className="text-[10px] text-slate-500">{auditor.activeAssignments} penugasan aktif</p>
                   </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {isCycleModalOpen && <CreateCycleModal onClose={() => setIsCycleModalOpen(false)} onSave={handleCreateCycle} />}
      {isAssignModalOpen && <AssignAuditorModal onClose={() => setIsAssignModalOpen(false)} onSave={handleAssignAuditor} allCycles={cycles} allUnits={allUnits} allAuditors={allAuditors}/>}
      {isDocModalOpen && <AddStandardDocModal onClose={() => setIsDocModalOpen(false)} onSave={handleAddDocument} />}
    </div>
  );
};

export default UPMAdminView;
